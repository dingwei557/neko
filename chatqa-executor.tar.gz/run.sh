#!/bin/bash

FILEPATH=""
PARAMS=""
REPORT_DIR="./reports"
AUTH_STATE=""

while getopts "f:p:d:a:" opt; do
  case $opt in
    f)
      FILEPATH="$OPTARG"
      ;;
    p)
      PARAMS="$OPTARG"
      ;;
    d)
      REPORT_DIR="$OPTARG"
      ;;
    a)
      AUTH_STATE="$OPTARG"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
    :)
      echo "Option -$OPTARG requires an argument" >&2
      exit 1
      ;;
  esac
done

export REPORT_DIR
export AUTH_STATE_PATH="$AUTH_STATE"
export CHATQA_RUNNER_BUNDLE=1

if [ -z "$FILEPATH" ]; then
  echo "Error: -f filepath is required" >&2
  exit 1
fi

# Find the executor JS file
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check and install dependencies if needed
if [[ ! -d "${SCRIPT_DIR}/node_modules" ]]; then
  echo "Installing dependencies..."
  cd "$SCRIPT_DIR"
  npm install --production --ignore-scripts
fi

# Try bundled JS first (development mode)
EXECUTOR_JS="${SCRIPT_DIR}/runner-bundle.js"

# If not found, try src/index.js (Runner deployed mode)
if [ ! -f "$EXECUTOR_JS" ]; then
  EXECUTOR_JS="${SCRIPT_DIR}/src/index.js"
fi

if [ ! -f "$EXECUTOR_JS" ]; then
  echo "Error: executor JS not found" >&2
  echo "  - Checked: $SCRIPT_DIR/runner-bundle.js" >&2
  echo "  - Checked: $SCRIPT_DIR/src/index.js" >&2
  echo "Please run 'npm run build:executor' first" >&2
  exit 1
fi

node "$EXECUTOR_JS" -f "$FILEPATH" -p "$PARAMS"
exit $?
