/**
 * chatqa-executor - Main entry point for TestHub Runner
 *
 * This script executes ChatQA test plans received from the TestHub Server.
 * It connects to a Unix socket for log streaming and produces HTML reports.
 *
 * Usage:
 *   node src/index.js -f spec.yaml -p '{"var1":"value1"}'
 *
 * Environment:
 *   LOCAL_SOCKET_PATH - Path to Unix socket for log streaming
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const net = require('net');
const https = require('https');
const http = require('http');
const { XMLParser } = require('fast-xml-parser');
const pixelmatch = require('pixelmatch');
const { PNG } = require('pngjs');

// ── Embedded Auth State ──────────────────────────────────────────────────
// Authentication state for authenticated browser sessions (d.stg.g123.jp)
const AUTH_STATE = {
  "cookies": [
    {
      "name": "__gp_clid",
      "value": "dftsSqA4_v83E36elsSaDf5MT6KOdo4sr_lLXCNibQpxo.5QiUby409MgE91Jiop4bCI",
      "domain": ".g123.jp",
      "path": "/",
      "expires": 1808444394.135238,
      "httpOnly": true,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "__gp_dvid",
      "value": "dftsSqA4_v83E36elsSaDf5MT6KOdo4sr_lLXCNibQpxo",
      "domain": ".g123.jp",
      "path": "/",
      "expires": 1808444385,
      "httpOnly": false,
      "secure": false,
      "sameSite": "Lax"
    },
    {
      "name": "__gp_ssid",
      "value": "dftsSqA4_v83E36elsSaDf5MT6KOdo4sr_lLXCNibQpxo.5QiUby409MgE91Jiop4bCI.moatdgxm",
      "domain": ".g123.jp",
      "path": "/",
      "expires": -1,
      "httpOnly": true,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "auth0",
      "value": "s%3AABGGISu2bnFh-tfYUzzAqQ72p3NKIQ2K.c4ocDgjm%2B015yexNA2CW5JMCKgwCiCLIhV631EUUaOs",
      "domain": "ctw.jp.auth0.com",
      "path": "/",
      "expires": 1777167595.155043,
      "httpOnly": true,
      "secure": true,
      "sameSite": "None"
    },
    {
      "name": "auth0_compat",
      "value": "s%3AABGGISu2bnFh-tfYUzzAqQ72p3NKIQ2K.c4ocDgjm%2B015yexNA2CW5JMCKgwCiCLIhV631EUUaOs",
      "domain": "ctw.jp.auth0.com",
      "path": "/",
      "expires": 1777167595.155205,
      "httpOnly": true,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "did",
      "value": "s%3Av0%3A62b263df-42a6-4045-b97b-e6a59aad2c7e%3A4cc2bd5b672a5a568867dff64f8ba59f0f630c361e23e4b3a3407a8d1de4695f.X3yOkdJ77AzOIQsQYVO%2BD9xoX2oDMr1bDeBTRoG5c8U",
      "domain": "ctw.jp.auth0.com",
      "path": "/",
      "expires": 1808465994.653478,
      "httpOnly": true,
      "secure": true,
      "sameSite": "None"
    },
    {
      "name": "did_compat",
      "value": "s%3Av0%3A62b263df-42a6-4045-b97b-e6a59aad2c7e%3A4cc2bd5b672a5a568867dff64f8ba59f0f630c361e23e4b3a3407a8d1de4695f.X3yOkdJ77AzOIQsQYVO%2BD9xoX2oDMr1bDeBTRoG5c8U",
      "domain": "ctw.jp.auth0.com",
      "path": "/",
      "expires": 1808465994.653681,
      "httpOnly": true,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "_dd_s",
      "value": "aid=d9ce8c46-0c7c-4bd0-b38b-5d6194bcbbb7&rum=1&id=219b2843-68fe-4884-9f04-d838704184af&created=1776908381796&expire=1776909296597",
      "domain": "d.stg.g123.jp",
      "path": "/",
      "expires": 1808444398,
      "httpOnly": false,
      "secure": false,
      "sameSite": "Strict"
    },
    {
      "name": "_legacy_auth0.IDhGOgDP6TQwkNpV2izJhalhySBI4DHz.is.authenticated",
      "value": "true",
      "domain": "d.stg.g123.jp",
      "path": "/",
      "expires": 1776994795,
      "httpOnly": false,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "_legacy_auth0.k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C.is.authenticated",
      "value": "true",
      "domain": "d.stg.g123.jp",
      "path": "/",
      "expires": 1776929274,
      "httpOnly": false,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "auth0.IDhGOgDP6TQwkNpV2izJhalhySBI4DHz.is.authenticated",
      "value": "true",
      "domain": "d.stg.g123.jp",
      "path": "/",
      "expires": 1776994795,
      "httpOnly": false,
      "secure": true,
      "sameSite": "None"
    },
    {
      "name": "auth0.k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C.is.authenticated",
      "value": "true",
      "domain": "d.stg.g123.jp",
      "path": "/",
      "expires": 1776929274,
      "httpOnly": false,
      "secure": true,
      "sameSite": "None"
    },
    {
      "name": "_dd_s",
      "value": "aid=3062f353-6f73-44b3-9348-51eeb000f9dd&rum=1&id=f2e4b145-74a9-4d40-b7c5-b3e79ce80b6d&created=1776842879150&expire=1776843779708",
      "domain": "fa-contract-gen-690068.stg.g123.jp",
      "path": "/",
      "expires": 1808378883,
      "httpOnly": false,
      "secure": false,
      "sameSite": "Strict"
    },
    {
      "name": "_legacy_auth0.IDhGOgDP6TQwkNpV2izJhalhySBI4DHz.is.authenticated",
      "value": "true",
      "domain": "fa-contract-gen-690068.stg.g123.jp",
      "path": "/",
      "expires": 1776926936,
      "httpOnly": false,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "_legacy_auth0.k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C.is.authenticated",
      "value": "true",
      "domain": "fa-contract-gen-690068.stg.g123.jp",
      "path": "/",
      "expires": 1776929274,
      "httpOnly": false,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "auth0.IDhGOgDP6TQwkNpV2izJhalhySBI4DHz.is.authenticated",
      "value": "true",
      "domain": "fa-contract-gen-690068.stg.g123.jp",
      "path": "/",
      "expires": 1776926936,
      "httpOnly": false,
      "secure": true,
      "sameSite": "None"
    },
    {
      "name": "auth0.k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C.is.authenticated",
      "value": "true",
      "domain": "fa-contract-gen-690068.stg.g123.jp",
      "path": "/",
      "expires": 1776929274,
      "httpOnly": false,
      "secure": true,
      "sameSite": "None"
    },
    {
      "name": "_legacy_auth0.k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C.is.authenticated",
      "value": "true",
      "domain": "fl-app.stg.g123.jp",
      "path": "/",
      "expires": 1776929274,
      "httpOnly": false,
      "secure": true,
      "sameSite": "Lax"
    },
    {
      "name": "auth0.k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C.is.authenticated",
      "value": "true",
      "domain": "fl-app.stg.g123.jp",
      "path": "/",
      "expires": 1776929274,
      "httpOnly": false,
      "secure": true,
      "sameSite": "None"
    }
  ],
  "origins": [
    {
      "origin": "https://d.stg.g123.jp",
      "localStorage": [
        {
          "name": "@@auth0spajs@@::IDhGOgDP6TQwkNpV2izJhalhySBI4DHz::metaknow::openid profile email offline_access",
          "value": "{\"body\":{\"access_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbIm1ldGFrbm93IiwiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTc3NjkwODM5NSwiZXhwIjoxNzc3NzcyMzk1LCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIG9mZmxpbmVfYWNjZXNzIiwiYXpwIjoiSURoR09nRFA2VFF3a05wVjJpekpoYWxoeVNCSTRESHoiLCJwZXJtaXNzaW9ucyI6W119.YtOM4Fk6oTMBBxNMunL2w35TLlt0x56p2YfePwSipHhRS2ykBMTFmMOL5lWgGNIU78o-kpnbH2WovRXLhVxfx_ea9BsVBPurPGtmf2Gc41oUf7IErePgqx8cdFe_9muTGcCAr1VCITEvxF1ToagKJ2UKubnUnSWGMZ-iZ1Vm1s8Q_lLTGYkjJEbYJF3yYrIPRosml7_Wljnk7kOi7QeJVxnlk_7fJsbQemdvYtZ4ZgtSN9J_k4XbErxUKmBrYHDkm-NaJzAEW4gMCI-kTyJ7oXsSSMag__35ikZ2UJvkWjKH6giOatmrzrF6mXa9i--YVtQ-yPBja8dwggsI4b_TTg\",\"refresh_token\":\"v1.MXMkqKZ0iAhz2z20QpNJ7w9OMglYO_ME7Qg-AVcYFSzbr0fWxrixOPEwPadDC0br3FnEwOibkDJ7TmiV8QOdxnw\",\"scope\":\"openid profile email offline_access\",\"expires_in\":864000,\"token_type\":\"Bearer\",\"audience\":\"metaknow\",\"oauthTokenScope\":\"openid profile email offline_access\",\"client_id\":\"IDhGOgDP6TQwkNpV2izJhalhySBI4DHz\"},\"expiresAt\":1777772395}"
        },
        {
          "name": "xiaobao-displayed",
          "value": "true"
        },
        {
          "name": "ls_interaction_mode",
          "value": "{\"state\":{\"interactionMode\":\"system\"},\"version\":0}"
        },
        {
          "name": "@@auth0spajs@@::IDhGOgDP6TQwkNpV2izJhalhySBI4DHz::@@user@@",
          "value": "{\"id_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIzVDAxOjM5OjU0LjcyN1oiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6IklEaEdPZ0RQNlRRd2tOcFYyaXpKaGFsaHlTQkk0REh6Iiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2OTA4Mzk1LCJleHAiOjE3Nzk1MDAzOTUsInNpZCI6Ilp6Vl9pNjB6bW1uRHZISFpSVDN5cmdZaW5sU29ZQURsIiwibm9uY2UiOiJZalZTTkU0eFVURkNaMnN5UnpOMWIwa3hkVzVRVEU1a1FYVkZXSEozWm5waVlubG9OMjVKWVhOV1pRPT0ifQ.HxOnurPX5G3vn9bhepCr1LaaLLNWKo5o6w0kWvw-dZuFEL8uUuqY0ANb1JjOx6Sft8mVXw5e16c93gtTUHpssflVVHLT-zq7Hwl4S1JebwWyoJMC-SxGeQFUdXn9W4ToEreHcC91DoY5fpx63L0BkewklD2D14Mrc41WvUXaH6Ki_VzdAXfkvPR8jPfc1by_389mGuIqeiluyz--MIIcRkqBy03_JVo5wXt_ambpthVCWwlynAAEdgwdG1Xj4_F5H9lckZ4KA2l70DAPkGGz_fbOjil2VVIz9L21neNU0AhYlemp6deIYRpHXMgorxjyyTA4sM7axcXKOk_cq5gugw\",\"decodedToken\":{\"encoded\":{\"header\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9\",\"payload\":\"eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIzVDAxOjM5OjU0LjcyN1oiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6IklEaEdPZ0RQNlRRd2tOcFYyaXpKaGFsaHlTQkk0REh6Iiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2OTA4Mzk1LCJleHAiOjE3Nzk1MDAzOTUsInNpZCI6Ilp6Vl9pNjB6bW1uRHZISFpSVDN5cmdZaW5sU29ZQURsIiwibm9uY2UiOiJZalZTTkU0eFVURkNaMnN5UnpOMWIwa3hkVzVRVEU1a1FYVkZXSEozWm5waVlubG9OMjVKWVhOV1pRPT0ifQ\",\"signature\":\"HxOnurPX5G3vn9bhepCr1LaaLLNWKo5o6w0kWvw-dZuFEL8uUuqY0ANb1JjOx6Sft8mVXw5e16c93gtTUHpssflVVHLT-zq7Hwl4S1JebwWyoJMC-SxGeQFUdXn9W4ToEreHcC91DoY5fpx63L0BkewklD2D14Mrc41WvUXaH6Ki_VzdAXfkvPR8jPfc1by_389mGuIqeiluyz--MIIcRkqBy03_JVo5wXt_ambpthVCWwlynAAEdgwdG1Xj4_F5H9lckZ4KA2l70DAPkGGz_fbOjil2VVIz9L21neNU0AhYlemp6deIYRpHXMgorxjyyTA4sM7axcXKOk_cq5gugw\"},\"header\":{\"alg\":\"RS256\",\"typ\":\"JWT\",\"kid\":\"SyJwIWizKvWhKUPOEpGLO\"},\"claims\":{\"__raw\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIzVDAxOjM5OjU0LjcyN1oiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6IklEaEdPZ0RQNlRRd2tOcFYyaXpKaGFsaHlTQkk0REh6Iiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2OTA4Mzk1LCJleHAiOjE3Nzk1MDAzOTUsInNpZCI6Ilp6Vl9pNjB6bW1uRHZISFpSVDN5cmdZaW5sU29ZQURsIiwibm9uY2UiOiJZalZTTkU0eFVURkNaMnN5UnpOMWIwa3hkVzVRVEU1a1FYVkZXSEozWm5waVlubG9OMjVKWVhOV1pRPT0ifQ.HxOnurPX5G3vn9bhepCr1LaaLLNWKo5o6w0kWvw-dZuFEL8uUuqY0ANb1JjOx6Sft8mVXw5e16c93gtTUHpssflVVHLT-zq7Hwl4S1JebwWyoJMC-SxGeQFUdXn9W4ToEreHcC91DoY5fpx63L0BkewklD2D14Mrc41WvUXaH6Ki_VzdAXfkvPR8jPfc1by_389mGuIqeiluyz--MIIcRkqBy03_JVo5wXt_ambpthVCWwlynAAEdgwdG1Xj4_F5H9lckZ4KA2l70DAPkGGz_fbOjil2VVIz9L21neNU0AhYlemp6deIYRpHXMgorxjyyTA4sM7axcXKOk_cq5gugw\",\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-23T01:39:54.727Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"iss\":\"https://ctw.jp.auth0.com/\",\"aud\":\"IDhGOgDP6TQwkNpV2izJhalhySBI4DHz\",\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\",\"iat\":1776908395,\"exp\":1779500395,\"sid\":\"ZzV_i60zmmnDvHHZRT3yrgYinlSoYADl\",\"nonce\":\"YjVSNE4xUTFCZ2syRzN1b0kxdW5QTE5kQXVFWHJ3ZnpiYnloN25JYXNWZQ==\"},\"user\":{\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-23T01:39:54.727Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\"}}}"
        },
        {
          "name": "editor-settings",
          "value": "{\"state\":{\"enterSendsMessage\":true},\"version\":1}"
        },
        {
          "name": "permission-storage",
          "value": "{\"state\":{\"userInfo\":{\"email\":\"ding.wei@ctw.inc\",\"location\":\"SHA\",\"avatar\":\"\",\"department_code\":\"tech\",\"position_code\":\"de\",\"roles\":[{\"id\":\"f3eb3848-5a44-42c4-9f82-f1aee1b376f1\",\"name\":\"members\",\"permissions\":[\"d:login:all\",\"d:use:da_agent\",\"mcp:use:all\"]},{\"id\":\"770f663e-1d54-46ca-9b73-dc15688cb2d7\",\"name\":\"global_labors\",\"permissions\":[]}],\"language\":\"\",\"conf\":{\"send_key\":\"\"},\"projects\":[],\"app_ids\":null,\"need_rotation\":false,\"features\":{\"pap\":false}},\"permissions\":[\"d:login:all\",\"d:use:da_agent\",\"mcp:use:all\"]},\"version\":0}"
        },
        {
          "name": "theme-storage",
          "value": "{\"state\":{\"mode\":\"system\"},\"version\":1}"
        },
        {
          "name": "ls_view_grid_collapsed_group",
          "value": "{\"state\":{\"collapsedGroupMap\":{}},\"version\":0}"
        },
        {
          "name": "ls_personal_view_map",
          "value": "{\"state\":{\"personalViewMap\":{}},\"version\":6}"
        },
        {
          "name": "accessToken",
          "value": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2NjgwODU4LCJleHAiOjE3NzY3NjcyNTgsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.MI-7ATXXlPlf017pYa7qtpQPgRXEWIuL4-IlYS5NlZDwrJ6le7VZjlVUjZi8uUD1VgqT9mj6qijDXPMthu7k9bSSJiabrw4iHwxULQ3dJgoisTwA60_zz4j4H6nzQdpbMmDi7OgQE7Pis9yK3jGSTqPBIzlJ0wzjnwePDoADDbYOyTqH5Rbd--fZVMakSx6wevk3EkxRqWioEqgYmFrsXAI4539yclQEzt8P3eRdxBUrO6GY7fGZ0uTYZ7AUVDg6mBoyWvDNyg9lhP2Ip4spYNwfuTV-7cACzQnNIA19CZ1NiVco3R0aQMQlwqcg8QrxngFei-1pgniiqs2YEl0Vfw"
        },
        {
          "name": "gp_dvid",
          "value": "dftsSqA4_v83E36elsSaDf5MT6KOdo4sr_lLXCNibQpxo"
        },
        {
          "name": "gp_dvtm",
          "value": "1776840520635"
        },
        {
          "name": "auth_token",
          "value": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g"
        },
        {
          "name": "@@auth0spajs@@::k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C::@@user@@",
          "value": "{\"id_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"decodedToken\":{\"encoded\":{\"header\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9\",\"payload\":\"eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ\",\"signature\":\"zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\"},\"header\":{\"alg\":\"RS256\",\"typ\":\"JWT\",\"kid\":\"SyJwIWizKvWhKUPOEpGLO\"},\"claims\":{\"__raw\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"iss\":\"https://ctw.jp.auth0.com/\",\"aud\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\",\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\",\"iat\":1776842874,\"exp\":1776878874,\"sid\":\"DbaH-4Sl7fxJA9bX7ALrVNAl0r209NF3\",\"nonce\":\"ZjdYd1RNNzNWb0FvdlVheEpYWEFXQkFQQ3BEMEdQeHA2YXp0T20uamFUUQ==\"},\"user\":{\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\"}}}"
        },
        {
          "name": "@@auth0spajs@@::k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C::default::openid profile email offline_access",
          "value": "{\"body\":{\"access_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g\",\"refresh_token\":\"v1.MerTGRUn9eXWHPe4dJGTcphOlN1YpvDZiaaeiGSP5OGhhd4FeEqJyRPrvGMqwZUX-vcFB1V7q0rzqHOEFri-e5A\",\"scope\":\"openid profile email offline_access\",\"expires_in\":86400,\"token_type\":\"Bearer\",\"audience\":\"default\",\"oauthTokenScope\":\"openid profile email offline_access\",\"client_id\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\"},\"expiresAt\":1776929274}"
        }
      ]
    },
    {
      "origin": "https://fa-contract-gen-690068.stg.g123.jp",
      "localStorage": [
        {
          "name": "@@auth0spajs@@::IDhGOgDP6TQwkNpV2izJhalhySBI4DHz::metaknow::openid profile email offline_access",
          "value": "{\"body\":{\"access_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g\",\"refresh_token\":\"v1.MerTGRUn9eXWHPe4dJGTcphOlN1YpvDZiaaeiGSP5OGhhd4FeEqJyRPrvGMqwZUX-vcFB1V7q0rzqHOEFri-e5A\",\"scope\":\"openid profile email offline_access\",\"expires_in\":86400,\"token_type\":\"Bearer\",\"audience\":\"default\",\"oauthTokenScope\":\"openid profile email offline_access\",\"client_id\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\"},\"expiresAt\":1776929274}"
        },
        {
          "name": "xiaobao-displayed",
          "value": "true"
        },
        {
          "name": "ls_interaction_mode",
          "value": "{\"state\":{\"interactionMode\":\"system\"},\"version\":0}"
        },
        {
          "name": "@@auth0spajs@@::IDhGOgDP6TQwkNpV2izJhalhySBI4DHz::@@user@@",
          "value": "{\"id_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"decodedToken\":{\"encoded\":{\"header\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9\",\"payload\":\"eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ\",\"signature\":\"zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\"},\"header\":{\"alg\":\"RS256\",\"typ\":\"JWT\",\"kid\":\"SyJwIWizKvWhKUPOEpGLO\"},\"claims\":{\"__raw\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"iss\":\"https://ctw.jp.auth0.com/\",\"aud\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\",\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\",\"iat\":1776842874,\"exp\":1776878874,\"sid\":\"DbaH-4Sl7fxJA9bX7ALrVNAl0r209NF3\",\"nonce\":\"ZjdYd1RNNzNWb0FvdlVheEpYWEFXQkFQQ3BEMEdQeHA2YXp0T20uamFUUQ==\"},\"user\":{\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\"}}}"
        },
        {
          "name": "accessToken",
          "value": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g"
        },
        {
          "name": "editor-settings",
          "value": "{\"state\":{\"enterSendsMessage\":true},\"version\":1}"
        },
        {
          "name": "permission-storage",
          "value": "{\"state\":{\"userInfo\":{\"email\":\"ding.wei@ctw.inc\",\"location\":\"SHA\",\"avatar\":\"\",\"department_code\":\"tech\",\"position_code\":\"de\",\"roles\":[{\"id\":\"f3eb3848-5a44-42c4-9f82-f1aee1b376f1\",\"name\":\"members\",\"permissions\":[\"d:login:all\",\"d:use:da_agent\",\"mcp:use:all\"]},{\"id\":\"770f663e-1d54-46ca-9b73-dc15688cb2d7\",\"name\":\"global_labors\",\"permissions\":[]}],\"language\":\"\",\"conf\":{\"send_key\":\"\"},\"projects\":[],\"app_ids\":null,\"need_rotation\":false,\"features\":{\"pap\":false}},\"permissions\":[\"d:login:all\",\"d:use:da_agent\",\"mcp:use:all\"]},\"version\":0}"
        },
        {
          "name": "theme-storage",
          "value": "{\"state\":{\"mode\":\"system\"},\"version\":1}"
        },
        {
          "name": "ls_view_grid_collapsed_group",
          "value": "{\"state\":{\"collapsedGroupMap\":{}},\"version\":0}"
        },
        {
          "name": "ls_personal_view_map",
          "value": "{\"state\":{\"personalViewMap\":{}},\"version\":6}"
        },
        {
          "name": "gp_dvid",
          "value": "dftsSqA4_v83E36elsSaDf5MT6KOdo4sr_lLXCNibQpxo"
        },
        {
          "name": "gp_dvtm",
          "value": "1776842861798"
        },
        {
          "name": "auth_token",
          "value": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g"
        },
        {
          "name": "@@auth0spajs@@::k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C::@@user@@",
          "value": "{\"id_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"decodedToken\":{\"encoded\":{\"header\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9\",\"payload\":\"eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ\",\"signature\":\"zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\"},\"header\":{\"alg\":\"RS256\",\"typ\":\"JWT\",\"kid\":\"SyJwIWizKvWhKUPOEpGLO\"},\"claims\":{\"__raw\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"iss\":\"https://ctw.jp.auth0.com/\",\"aud\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\",\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\",\"iat\":1776842874,\"exp\":1776878874,\"sid\":\"DbaH-4Sl7fxJA9bX7ALrVNAl0r209NF3\",\"nonce\":\"ZjdYd1RNNzNWb0FvdlVheEpYWEFXQkFQQ3BEMEdQeHA2YXp0T20uamFUUQ==\"},\"user\":{\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\"}}}"
        },
        {
          "name": "@@auth0spajs@@::k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C::default::openid profile email offline_access",
          "value": "{\"body\":{\"access_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g\",\"refresh_token\":\"v1.MerTGRUn9eXWHPe4dJGTcphOlN1YpvDZiaaeiGSP5OGhhd4FeEqJyRPrvGMqwZUX-vcFB1V7q0rzqHOEFri-e5A\",\"scope\":\"openid profile email offline_access\",\"expires_in\":86400,\"token_type\":\"Bearer\",\"audience\":\"default\",\"oauthTokenScope\":\"openid profile email offline_access\",\"client_id\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\"},\"expiresAt\":1776929274}"
        }
      ]
    },
    {
      "origin": "https://fl-app.stg.g123.jp",
      "localStorage": [
        {
          "name": "auth_token",
          "value": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g"
        },
        {
          "name": "@@auth0spajs@@::k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C::@@user@@",
          "value": "{\"id_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"decodedToken\":{\"encoded\":{\"header\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9\",\"payload\":\"eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ\",\"signature\":\"zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\"},\"header\":{\"alg\":\"RS256\",\"typ\":\"JWT\",\"kid\":\"SyJwIWizKvWhKUPOEpGLO\"},\"claims\":{\"__raw\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJnaXZlbl9uYW1lIjoiIiwiZmFtaWx5X25hbWUiOiLkuIHngpwiLCJuaWNrbmFtZSI6ImRpbmcud2VpIiwibmFtZSI6IuS4geeCnCIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInVwZGF0ZWRfYXQiOiIyMDI2LTA0LTIyVDA3OjI3OjUzLjMxNloiLCJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9jdHcuanAuYXV0aDAuY29tLyIsImF1ZCI6ImsxaVh1NlUzeXN0Q2NCUHJJMXlNTm9aSHZLUkR6bzlDIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY4Nzg4NzQsInNpZCI6IkRiYUgtNFNsN2Z4SkE5Ylg3QUxyVk5BbDByMjA5TkYzIiwibm9uY2UiOiJaamRZZDFSTk56TldiMEZ2ZGxWaGVFcFlXRUZYUWtGUVEzQkVNRWRRZUhBMllYcDBUMjB1YW1GVVVRPT0ifQ.zG_CwVHgg3d8IzDvS17MAqdk9MqYByfwDD3rJjG0ksttS2oxlYBF4mGjnfPNddyKUfc46LiGYGzvLdWRmaY7iidBoHjEZ8Y2iLuggWE2Ou0dPvQsz52iHmVOFR-oJQx30dyX66CCHT9nuh4EQY-wPaktHFYWodsgrG8KX5sW40N6_Ldppsog-3vrPyTSGVas2y5FS8a_rHha4sx7wkSkDa5NZRzAAgkOb7QasjLT0P5YhIr2b6rt_VJwhzM4HKPKBwbOLMT_gRTIbT2PhgF_F7Eu5c2EOqxY8YMSyMFX7IOKKkCfX1XM2wv2aBIdHIb3h0ZxjwTTqYeD5Z9yNWCZ8Q\",\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"iss\":\"https://ctw.jp.auth0.com/\",\"aud\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\",\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\",\"iat\":1776842874,\"exp\":1776878874,\"sid\":\"DbaH-4Sl7fxJA9bX7ALrVNAl0r209NF3\",\"nonce\":\"ZjdYd1RNNzNWb0FvdlVheEpYWEFXQkFQQ3BEMEdQeHA2YXp0T20uamFUUQ==\"},\"user\":{\"given_name\":\"\",\"family_name\":\"丁炜\",\"nickname\":\"ding.wei\",\"name\":\"丁炜\",\"picture\":\"https://static.dingtalk.com/media/lQDPM5T6e4lTbfHNAn7NA1WwlWM8ReYaEEMIeJ6L1CZ-AA_853_638.jpg_120x120q90.jpg?bizType=avatar\",\"updated_at\":\"2026-04-22T07:27:53.316Z\",\"email\":\"ding.wei@ctw.inc\",\"email_verified\":true,\"sub\":\"oidc|g123-sso|ding.wei@ctw.inc\"}}}"
        },
        {
          "name": "@@auth0spajs@@::k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C::default::openid profile email offline_access",
          "value": "{\"body\":{\"access_token\":\"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlN5SndJV2l6S3ZXaEtVUE9FcEdMTyJ9.eyJlbWFpbCI6ImRpbmcud2VpQGN0dy5pbmMiLCJuYW1lIjoi5LiB54KcIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoi5LiB54KcIiwibmlja25hbWUiOiJkaW5nLndlaSIsInBpY3R1cmUiOiJodHRwczovL3N0YXRpYy5kaW5ndGFsay5jb20vbWVkaWEvbFFEUE01VDZlNGxUYmZITkFuN05BMVd3bFdNOFJlWWFFRU1JZUo2TDFDWi1BQV84NTNfNjM4LmpwZ18xMjB4MTIwcTkwLmpwZz9iaXpUeXBlPWF2YXRhciIsInJvbGUiOlsiY3R3Ym94OmVkaXRvciIsImN0d2JveDp2aWV3ZXIiLCJwaXg6ZWRpdG9yIiwidy1zeXN0ZW06dXNlciJdLCJhcHBfbWV0YWRhdGEiOnsiYXBwX2lkcyI6bnVsbCwiaTE5bl9wZXJtaXNzaW9ucyI6WyIqOio6Y3JlYXRlX2dhbWUiLCIqOio6Y3R3IiwiKjoqOmNwIl0sIm9ncmVfcGVybWlzc2lvbnMiOlsiKjoqOmdlbmVyYWxFbXBsb3llZSJdLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCJ9LCJpc3MiOiJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vIiwic3ViIjoib2lkY3xnMTIzLXNzb3xkaW5nLndlaUBjdHcuaW5jIiwiYXVkIjpbImN0dzIiLCJodHRwczovL2N0dy5qcC5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNzc2ODQyODc0LCJleHAiOjE3NzY5MjkyNzQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhenAiOiJrMWlYdTZVM3lzdENjQlBySTF5TU5vWkh2S1JEem85QyIsInBlcm1pc3Npb25zIjpbXX0.mXr6vIvoqmgiThbjz9HTHRvtSYu3qgutbRPkXKSNxqMHV8SwkwfAY_z8Xl1xbtVj2Q8QkOWzTKJGD_CCmdZKqDGF9maXCkGj3gkFg04k5ET74U9nohZ1fwNxTTlghdPskhG81NNG0M5e56IB0ujPGdb8BJEU9H3xgpvKBoKjOvv49BTN9SfZiG0U2fetDehfqnWu7O_pb6zGIs1Hdo7SSTrUjS8lzfUFunr42ccK_TDZ1HQZijZI8_jgfLUSsRmG-vPpfC35Or-78wnafyD_V6bcSRZHALlBS-zKK6z3jDzX-M0rIGXUGLw6ySmNr9xxlukOGhFBGSuKed0tcjQR6g\",\"refresh_token\":\"v1.MerTGRUn9eXWHPe4dJGTcphOlN1YpvDZiaaeiGSP5OGhhd4FeEqJyRPrvGMqwZUX-vcFB1V7q0rzqHOEFri-e5A\",\"scope\":\"openid profile email offline_access\",\"expires_in\":86400,\"token_type\":\"Bearer\",\"audience\":\"default\",\"oauthTokenScope\":\"openid profile email offline_access\",\"client_id\":\"k1iXu6U3ystCcBPrI1yMNoZHvKRDzo9C\"},\"expiresAt\":1776929274}"
        }
      ]
    },
    {
      "origin": "https://h5.g123.jp",
      "localStorage": [
        {
          "name": "gp_dvid",
          "value": "dftsSqA4_v83E36elsSaDf5MT6KOdo4sr_lLXCNibQpxo"
        },
        {
          "name": "gp_dvtm",
          "value": "1776908385054"
        }
      ]
    }
  ]
};

// ── CLI Argument Parsing ───────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  const opts = { specFile: 'spec.yaml', variables: {} };

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-f' && args[i + 1]) {
      opts.specFile = args[++i];
    } else if (args[i] === '-p' && args[i + 1]) {
      try {
        opts.variables = JSON.parse(args[++i]);
      } catch (e) {
        console.error(`Failed to parse variables JSON: ${e.message}`);
        process.exit(1);
      }
    }
  }

  return opts;
}

// ── Socket Logger ──────────────────────────────────────────────────────────

class SocketLogger {
  constructor(socketPath) {
    this.socketPath = socketPath || process.env.LOCAL_SOCKET_PATH;
    this.connected = false;
    this.queue = [];
    this._connect();
  }

  _connect() {
    if (!this.socketPath) {
      this.connected = true;
      return;
    }
    this.client = net.createConnection({ path: this.socketPath }, () => {
      this.connected = true;
      this._flush();
    });
    this.client.on('error', () => {});
  }

  _flush() {
    while (this.queue.length > 0 && this.connected) {
      const msg = this.queue.shift();
      this.client.write(msg + '\n');
    }
  }

  push(message) {
    const ts = new Date().toISOString();
    const log = `[${ts}] ${message}`;
    console.log(log);
    if (this.connected && this.client) {
      // Send as JSON-formatted message to match Runner's expected format
      const jsonMessage = JSON.stringify({ timestamp: ts, message: message });
      this.client.write(jsonMessage + '\n');
    }
  }

  close() {
    if (this.client) {
      this.client.end();
    }
  }
}

// ── Spec Loading ───────────────────────────────────────────────────────────

function loadSpec(specFile) {
  const content = fs.readFileSync(specFile, 'utf-8');
  return JSON.parse(content);
}

// ── Variable Substitution ──────────────────────────────────────────────────

function resolveVariables(obj, variables) {
  if (typeof obj === 'string') {
    return obj.replace(/\$\{(\w+)\}/g, (_, key) => {
      return variables[key] !== undefined ? variables[key] : _;
    });
  }
  if (Array.isArray(obj)) {
    return obj.map(item => resolveVariables(item, variables));
  }
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      result[k] = resolveVariables(v, variables);
    }
    return result;
  }
  return obj;
}

// ── Unicode Cleaning ───────────────────────────────────────────────────────

function cleanTargetText(target) {
  return target
    .replace(/[\u2318\u21E7\u2325\u2303\u23CE\u2190\u2191\u2192\u2193\u238B\u2326\u232B\u21A9]/g, '')
    .replace(/[\n\r\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function escapeCssAttributeValue(value) {
  return (value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

// ── Target Resolution ──────────────────────────────────────────────────────

async function resolveTarget(page, target) {
  target = cleanTargetText(target);
  const attrSafe = escapeCssAttributeValue(target);

  // 1. XPath expression
  if (/^\/\//.test(target) || /^\/[a-zA-Z*]/.test(target)) {
    try {
      const loc = page.locator(`xpath=${target}`);
      if ((await loc.count().catch(() => 0)) >= 1) {
        const first = loc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 2. CSS selector
  if (/^[a-z][\w-]*(\[|\.|\#| |>|,|:)/i.test(target) || /^\[/.test(target) || /^\./.test(target) || /^#/.test(target)) {
    try {
      const loc = page.locator(target);
      if ((await loc.count().catch(() => 0)) >= 1) {
        const first = loc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 3. data-testid
  try {
    const testIdLoc = page.locator(`[data-testid="${attrSafe}"]`);
    if ((await testIdLoc.count().catch(() => 0)) >= 1) {
      const first = testIdLoc.first();
      if (await first.isVisible().catch(() => false)) return first;
    }
  } catch {}

  // 4. name attribute
  try {
    const nameLoc = page.locator(`[name="${attrSafe}"]`);
    if ((await nameLoc.count().catch(() => 0)) >= 1) {
      const first = nameLoc.first();
      if (await first.isVisible().catch(() => false)) return first;
    }
  } catch {}

  // 5. href matching
  if ((target.startsWith('/') && !target.startsWith('//')) || target.startsWith('http')) {
    try {
      const hrefLoc = page.locator(`a[href*="${attrSafe}"]`);
      const count = await hrefLoc.count().catch(() => 0);
      if (count === 1) {
        const first = hrefLoc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 6. Attribute expressions: aria-label="..." etc.
  const attrMatch = target.match(/^(aria-label|aria-labelledby|title|name|placeholder|role)\s*=\s*"?([^"]+)"?$/i);
  if (attrMatch) {
    const [, attr, value] = attrMatch;
    const sel = `[${attr}="${escapeCssAttributeValue(value)}"]`;
    try {
      const loc = page.locator(sel);
      if ((await loc.count().catch(() => 0)) >= 1) {
        const first = loc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
    // Try contains
    const selContains = `[${attr}*="${escapeCssAttributeValue(value)}" i]`;
    try {
      const loc = page.locator(selContains);
      if ((await loc.count().catch(() => 0)) >= 1) {
        return loc.first();
      }
    } catch {}
  }

  // 7. Semantic roles - exact matches
  const semanticStrategies = [
    () => page.getByRole('button', { name: target, exact: true }),
    () => page.getByRole('link', { name: target, exact: true }),
    () => page.getByRole('textbox', { name: target, exact: true }),
    () => page.getByRole('checkbox', { name: target, exact: true }),
    () => page.getByRole('menuitem', { name: target, exact: true }),
    () => page.getByLabel(target, { exact: true }),
    () => page.getByPlaceholder(target, { exact: true }),
    () => page.locator(`[contenteditable]:text-is("${attrSafe}")`),
    () => page.getByText(target, { exact: true }),
  ];

  for (const strategy of semanticStrategies) {
    try {
      const locator = strategy();
      const count = await locator.count();
      if (count === 1) {
        const first = locator.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 8. Fuzzy text match (only if unique)
  try {
    const textLoc = page.getByText(target, { exact: false });
    const count = await textLoc.count();
    if (count === 1) {
      const first = textLoc.first();
      if (await first.isVisible().catch(() => false)) return first;
    }
  } catch {}

  throw new Error(`Cannot resolve target "${target}"`);
}

async function resolveTargetSafe(page, target) {
  try {
    return await resolveTarget(page, target);
  } catch {
    return null;
  }
}

async function resolveFillTarget(page, target) {
  const cleanTarget = cleanTargetText(target);
  const FILLABLE_TAGS = new Set(['input', 'textarea', 'select']);

  // Native fillable elements
  const fillSelectors = [
    () => page.getByRole('textbox', { name: cleanTarget }),
    () => page.getByLabel(cleanTarget),
    () => page.getByPlaceholder(cleanTarget),
    () => page.locator(`input[name*="${cleanTarget.replace(/"/g, '\\"')}" i]`),
    () => page.locator(`textarea[placeholder*="${cleanTarget.replace(/"/g, '\\"')}" i]`),
  ];

  for (const strategy of fillSelectors) {
    try {
      const locator = strategy();
      const count = await locator.count();
      if (count < 1) continue;
      for (let ci = 0; ci < Math.min(count, 5); ci++) {
        const el = locator.nth(ci);
        const info = await el.evaluate((e) => ({
          tag: e.tagName.toLowerCase(),
          visible: e.offsetParent !== null,
        })).catch(() => ({ tag: '?', visible: true }));

        if (info.visible && FILLABLE_TAGS.has(info.tag)) return el;
      }
    } catch { continue; }
  }

  // Contenteditable elements
  const ceSelectors = [
    `[contenteditable="true"][aria-label*="${cleanTarget.replace(/"/g, '\\"')}" i]`,
    `[contenteditable="true"][placeholder*="${cleanTarget.replace(/"/g, '\\"')}" i]`,
    '[contenteditable="true"]',
    '[contenteditable=""]',
  ];
  for (const sel of ceSelectors) {
    try {
      const loc = page.locator(sel);
      const count = await loc.count();
      if (count < 1) continue;
      for (let ci = 0; ci < Math.min(count, 3); ci++) {
        const el = loc.nth(ci);
        const vis = await el.evaluate((e) => {
          const rect = e.getBoundingClientRect();
          return rect.width > 0 && rect.height > 0;
        }).catch(() => false);
        if (vis) return el;
      }
    } catch { continue; }
  }

  // Fallback
  return resolveTarget(page, target);
}

async function ensureVisible(loc, target) {
  await loc.waitFor({ state: 'visible', timeout: 5000 }).catch(() => {
    loc.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
  });
}

// ── Assertion Execution ────────────────────────────────────────────────────

async function executeAssertion(page, assertion, capturedRequests = [], logger = { push: () => {} }) {
  if (!assertion) return { passed: true, actual: '' };

  switch (assertion.type) {
    case 'visible':
    case 'text_contains':
    case 'text_equals':
    case 'exists': {
      const target = cleanTargetText(assertion.expected || '');
      if (isSelectorLike(target)) {
        await page.waitForSelector(target, { state: 'visible', timeout: 10000 });
      } else {
        await page.getByText(target).waitFor({ state: 'visible', timeout: 10000 });
      }
      return { passed: true, actual: assertion.expected };
    }

    case 'not_visible': {
      const target = cleanTargetText(assertion.expected || '');
      if (isSelectorLike(target)) {
        await page.waitForSelector(target, { state: 'hidden', timeout: 10000 });
      } else {
        await page.getByText(target).waitFor({ state: 'hidden', timeout: 10000 });
      }
      return { passed: true, actual: 'hidden' };
    }

    case 'not_empty': {
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert not_empty 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const text = await loc.textContent().catch(() => '') || '';
      const trimmed = text.trim();
      return { passed: trimmed.length > 0, actual: trimmed.length > 0 ? `有内容: "${trimmed.substring(0, 80)}"` : '内容为空' };
    }

    case 'enabled': {
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert enabled 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const isEnabled = await loc.isEnabled().catch(() => false);
      const isVisible = await loc.isVisible().catch(() => false);
      if (!isVisible) return { passed: false, actual: `"${searchKey}" 不可见` };
      return { passed: isEnabled, actual: isEnabled ? `"${searchKey}" 可用` : `"${searchKey}" 已禁用` };
    }

    case 'disabled': {
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert disabled 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const isEnabled = await loc.isEnabled().catch(() => false);
      const isVisible = await loc.isVisible().catch(() => false);
      if (!isVisible) return { passed: false, actual: `"${searchKey}" 不可见` };
      return { passed: !isEnabled, actual: !isEnabled ? `"${searchKey}" 已禁用` : `"${searchKey}" 仍可用` };
    }

    case 'attribute_contains': {
      const expectedRaw = assertion.expected || '';
      const eqIndex = expectedRaw.indexOf('=');
      if (eqIndex < 0) return { passed: false, actual: 'attribute_contains expected 格式应为 "attr=value"' };
      const attrName = expectedRaw.substring(0, eqIndex).trim();
      const attrExpected = expectedRaw.substring(eqIndex + 1).trim();
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert attribute_contains 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const attrValue = await loc.getAttribute(attrName).catch(() => null);
      if (attrValue === null) return { passed: false, actual: `"${searchKey}" 没有属性 "${attrName}"` };
      const contains = attrValue.includes(attrExpected);
      return { passed: contains, actual: contains ? `${attrName}="${attrValue.substring(0, 100)}" 包含 "${attrExpected}"` : `${attrName}="${attrValue.substring(0, 100)}" 不含 "${attrExpected}"` };
    }

    case 'url_contains': {
      const url = page.url();
      if (url.includes(assertion.expected || '')) {
        return { passed: true, actual: url };
      }
      return { passed: false, actual: url };
    }

    case 'href_exists': {
      const loc = page.locator(`a:has-text("${assertion.expected}")`);
      const count = await loc.count();
      return { passed: count > 0, actual: count > 0 ? 'exists' : 'not found' };
    }

    case 'href_not_exists': {
      const loc = page.locator(`a:has-text("${assertion.expected}")`);
      const count = await loc.count();
      return { passed: count === 0, actual: count === 0 ? 'not exists' : 'exists' };
    }

    case 'count_gte': {
      const target = cleanTargetText(assertion.expected || '');
      const match = target.match(/(.*)\s*>=\s*(\d+)/);
      if (match) {
        const [, selectorPart, countPart] = match;
        const count = await page.locator(selectorPart.trim()).count();
        return { passed: count >= parseInt(countPart, 10), actual: String(count) };
      }
      return { passed: true, actual: '' };
    }

    case 'api_status': {
      const urlPattern = assertion.api_url_pattern || assertion.expected || '';
      const expectedStatus = parseInt(assertion.expected || '200', 10);
      if (!urlPattern) return { passed: false, actual: 'api_status 缺少 api_url_pattern 或 target' };
      const matching = capturedRequests.filter(r => r.url.includes(urlPattern));
      if (matching.length === 0) return { passed: false, actual: `未捕获到匹配 "${urlPattern}" 的请求` };
      const last = matching[matching.length - 1];
      return { passed: last.status === expectedStatus, actual: `${last.method} ${last.url.substring(0, 100)} -> ${last.status}` };
    }

    case 'api_body_contains': {
      const urlPattern = assertion.api_url_pattern || assertion.expected || '';
      const expectedText = assertion.expected || '';
      if (!urlPattern) return { passed: false, actual: 'api_body_contains 缺少 api_url_pattern 或 target' };
      if (!expectedText) return { passed: false, actual: 'api_body_contains 缺少 expected' };
      const matching = capturedRequests.filter(r => r.url.includes(urlPattern));
      if (matching.length === 0) return { passed: false, actual: `未捕获到匹配 "${urlPattern}" 的请求` };
      const last = matching[matching.length - 1];
      const contains = (last.bodySnippet || '').includes(expectedText);
      return { passed: contains, actual: contains ? 'API 响应包含预期内容' : `API 响应不含预期内容 (前200: "${(last.bodySnippet || '').substring(0, 200)}")` };
    }

    case 'llm_judge': {
      const expected = assertion.expected || '';
      if (!expected) return { passed: false, actual: 'llm_judge 缺少 expected（语义预期描述）' };

      // Extract page text
      let pageText = '';
      if (assertion.target) {
        const loc = await resolveTargetSafe(page, assertion.target);
        pageText = loc ? (await loc.textContent().catch(() => '') || '') : await page.textContent('body').catch(() => '') || '';
      } else {
        pageText = await page.textContent('body').catch(() => '') || '';
      }

      // Take screenshot
      let screenshotBase64;
      try {
        const buf = await page.screenshot({ fullPage: false });
        screenshotBase64 = buf.toString('base64');
      } catch (e) {
        logger.push(`[llm_judge] Screenshot capture failed: ${e.message}`);
      }

      // Call D proxy LLM API
      const result = await callLlmJudge(pageText, expected, screenshotBase64, logger);
      return { passed: result.passed, actual: `LLM判定: ${result.reason}` };
    }

    default:
      return { passed: true, actual: `unsupported type: ${assertion.type}` };
  }
}

function isSelectorLike(target) {
  return target.startsWith('#') || target.startsWith('.') || target.startsWith('[') ||
    /^[a-z][\w-]*[>\s]/.test(target);
}

// ── LLM Judge (D Proxy API) ──────────────────────────────────────────────

/**
 * Call D proxy LLM API for semantic assertion judgment.
 * Uses environment variables for configuration:
 *   D_PROXY_BASE_URL / D_PROXY_CHAT_COMPLETIONS_URL - API base URL
 *   D_PROXY_MODEL - Model name (default: gpt-5.4)
 *   D_PROXY_SYSTEM - X-System header (default: ai-qa-stg)
 *   D_PROXY_SOURCE - X-Source header (default: same as system)
 *   D_PROXY_SIGNATURE - X-Signature header (required)
 *
 * @param {string} pageText - Extracted page text content
 * @param {string} expected - Semantic expectation description
 * @param {string} [screenshotBase64] - Optional screenshot in base64
 * @param {object} logger - Logger with .push() method
 * @returns {Promise<{passed: boolean, reason: string}>}
 */
async function callLlmJudge(pageText, expected, screenshotBase64, logger) {
  const nodeEnv = process.env.NODE_ENV || 'staging';
  const defaultBaseURL = nodeEnv === 'production'
    ? 'https://d.g123.jp/api/v1/proxy/llm'
    : 'https://d.stg.g123.jp/api/v1/proxy/llm';

  const baseURL = process.env.D_PROXY_CHAT_COMPLETIONS_URL ||
                  process.env.D_PROXY_BASE_URL ||
                  defaultBaseURL;
  const model = process.env.D_PROXY_MODEL || 'gpt-5.4';
  const system = process.env.D_PROXY_SYSTEM || 'core_qa';
  const source = process.env.D_PROXY_SOURCE || 'core_qa';
  const signature = process.env.D_PROXY_SIGNATURE;

  if (!signature) {
    logger.push('[llm_judge] WARNING: D_PROXY_SIGNATURE not set, LLM call will likely fail');
  }

  const systemPrompt = `你是一个 Web UI 测试断言裁判。你的任务是判断当前页面内容是否满足用户的语义预期。

## 输入
- 页面文本内容（已提取）
- 语义预期描述（自然语言）
${screenshotBase64 ? '- 页面截图' : ''}

## 判断规则
- 不要求精确的文字匹配，只要语义上满足预期即可
- 例如预期"AI引导用户提供请假天数"，只要页面上有类似"请问您想请几天？"、"需要请多少天假？"、"请告诉我具体的请假天数"等任意一种表述，都算通过
- 如果页面内容与预期完全无关，或者明显不满足预期语义，则判定失败
- 对回复质量也要判断：如果预期"正确引导"但AI回复了无关内容或错误信息，应判定失败

## 输出格式（严格 JSON，不要输出其他内容）
{
  "passed": true/false,
  "reason": "简要说明判断依据（30字以内）"
}`;

  const userContent = [
    { type: 'text', text: `语义预期：${expected}\n\n页面文本内容：\n${pageText.substring(0, 3000)}` },
  ];
  if (screenshotBase64) {
    userContent.push({
      type: 'image_url',
      image_url: { url: `data:image/png;base64,${screenshotBase64}` },
    });
  }

  const requestBody = {
    model,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userContent },
    ],
    temperature: 0,
    max_tokens: 200,
  };

  const bodyJson = JSON.stringify(requestBody);

  return new Promise((resolve) => {
    const url = new URL(baseURL.replace(/\/chat\/completions\/?$/i, '') + '/chat/completions');
    const options = {
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.D_PROXY_API_KEY || 'd-proxy'}`,
        'X-System': system,
        'X-Source': source,
        'Content-Length': Buffer.byteLength(bodyJson),
      },
      timeout: 30000,
    };

    if (signature) {
      options.headers['X-Signature'] = signature;
    }

    logger.push(`[llm_judge] Calling ${url.origin} with model=${model}, expected="${expected.substring(0, 50)}..."`);

    const req = (url.protocol === 'https:' ? https : http).request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          if (res.statusCode !== 200) {
            logger.push(`[llm_judge] HTTP ${res.statusCode}: ${data.substring(0, 200)}`);
            resolve({ passed: false, reason: `LLM API 返回错误: HTTP ${res.statusCode}` });
            return;
          }
          const parsed = JSON.parse(data);
          const content = parsed.choices?.[0]?.message?.content || '{}';
          // Extract JSON from response (may be wrapped in markdown code blocks)
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          if (!jsonMatch) {
            logger.push(`[llm_judge] No JSON found in response: ${content.substring(0, 200)}`);
            resolve({ passed: false, reason: 'LLM 返回格式错误' });
            return;
          }
          const result = JSON.parse(jsonMatch[0]);
          logger.push(`[llm_judge] Result: passed=${result.passed}, reason="${result.reason}"`);
          resolve({ passed: !!result.passed, reason: result.reason || '无判断依据' });
        } catch (err) {
          logger.push(`[llm_judge] Parse error: ${err.message}`);
          resolve({ passed: false, reason: `LLM 解析失败: ${err.message}` });
        }
      });
    });

    req.on('error', (err) => {
      logger.push(`[llm_judge] Request error: ${err.message}`);
      resolve({ passed: false, reason: `LLM 请求失败: ${err.message}` });
    });

    req.on('timeout', () => {
      req.destroy();
      logger.push('[llm_judge] Request timeout');
      resolve({ passed: false, reason: 'LLM 请求超时' });
    });

    req.write(bodyJson);
    req.end();
  });
}

// ── Step Execution ─────────────────────────────────────────────────────────

async function executeStep(page, step, index, logger, stepContext, hoverOnlyTargets, capturedRequests, screenshotDir) {
  const start = Date.now();

  // Resolve ${varName} in target/value/assertion
  const resolveVars = (s) => {
    if (!s || typeof s !== 'string' || !s.includes('${')) return s;
    return s.replace(/\$\{(\w+)\}/g, (_m, name) => {
      const val = stepContext.get(name);
      return val !== undefined ? val : _m;
    });
  };
  step.target = resolveVars(step.target);
  step.value = resolveVars(step.value);
  if (step.assertion?.expected) {
    step.assertion.expected = resolveVars(step.assertion.expected);
  }

  // Skip flag
  if (step.skip) {
    return {
      stepIndex: index, action: step.action, target: step.target, value: step.value,
      passed: true, skipped: true, reason: step.skip === true ? '标记为跳过' : String(step.skip),
      durationMs: 0,
    };
  }

  // Auto-hover for hover-only elements before click/assert
  if ((step.action === 'click' || step.action === 'assert') && step.target && hoverOnlyTargets.size > 0) {
    const isHoverOnly = hoverOnlyTargets.has(step.target) ||
      Array.from(hoverOnlyTargets).some(ht => step.target.includes(ht) || ht.includes(step.target));
    if (isHoverOnly) {
      try {
        const hoverLoc = await resolveTargetSafe(page, step.target);
        if (hoverLoc && await hoverLoc.count() > 0) {
          logger.push(`[auto-hover] Hovering hover-only target "${step.target}"`);
          await hoverLoc.hover({ timeout: 8000 });
          await page.waitForTimeout(300);
        }
      } catch (e) {
        logger.push(`[auto-hover] Failed for "${step.target}": ${e.message}`);
      }
    }
  }

  try {
    switch (step.action) {
      case 'navigate': {
        const url = step.value || step.target || '';
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.waitForLoadState('networkidle', { timeout: 12000 }).catch(() => {});
        await page.waitForTimeout(500);
        logger.push(`[navigate] Loaded: ${page.url()}`);
        break;
      }

      case 'template': {
        // Template step: extract selector from templateName and resolve to actual element
        // templateName format: "点击「[data-testid=\"xxx\"]」" or "等待「selector」出现"
        const templateName = step.templateName || '';
        const selectorMatch = templateName.match(/["「]([^"」]+)["」]/);
        const extractedTarget = selectorMatch ? selectorMatch[1] : templateName;
        logger.push(`[template] templateId=${step.templateId}, resolved target: ${extractedTarget}`);

        // Try to resolve and interact with the element
        try {
          const loc = await resolveTargetSafe(page, extractedTarget);
          if (loc) {
            const isVisible = await loc.isVisible().catch(() => false);
            logger.push(`[template] Element "${extractedTarget}" visible: ${isVisible}`);
          } else {
            logger.push(`[template] Element "${extractedTarget}" not found on current page`);
          }
        } catch (e) {
          logger.push(`[template] Resolution warning: ${e.message}`);
        }
        break;
      }

      case 'click': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        const elInfo = await loc.evaluate((el) => ({
          tag: el.tagName.toLowerCase(),
          text: (el.textContent || '').trim().substring(0, 80),
        })).catch(() => ({ tag: '?', text: '' }));

        // Auto-convert to selectOption for <select>
        if (elInfo.tag === 'select' && step.value) {
          logger.push(`[click] <select> detected -> selectOption("${step.value}")`);
          await loc.selectOption(step.value, { timeout: 10000 });
        } else {
          await loc.click({ timeout: 10000 });
        }
        logger.push(`[click] Clicked: ${step.target}`);
        break;
      }

      case 'fill': {
        const loc = await resolveFillTarget(page, step.target);
        await ensureVisible(loc, step.target);
        const elInfo = await loc.evaluate((el) => ({
          tag: el.tagName.toLowerCase(),
          contentEditable: el.isContentEditable || el.getAttribute('contenteditable') === 'true',
        })).catch(() => ({ tag: '?', contentEditable: false }));

        const nativeFillable = ['input', 'textarea', 'select'].includes(elInfo.tag);
        if (nativeFillable) {
          await loc.fill(step.value || '', { timeout: 10000 });
        } else if (elInfo.contentEditable) {
          await loc.click({ timeout: 5000 });
          const fillValue = step.value || '';
          const needsClipboard = /[`\n\r\t]/.test(fillValue) || fillValue.length > 200;

          if (needsClipboard) {
            let filled = false;
            // Strategy 1: real clipboard paste
            try {
              await page.evaluate(async (text) => { await navigator.clipboard.writeText(text); }, fillValue);
              const modifier = process.platform === 'darwin' ? 'Meta' : 'Control';
              await page.keyboard.press(`${modifier}+v`);
              await page.waitForTimeout(300);
              const content = await loc.evaluate((el) => (el).innerText.trim());
              if (content.length > 0) { filled = true; logger.push('[fill] Strategy 1 (clipboard) succeeded'); }
            } catch (e) { logger.push(`[fill] Strategy 1 failed: ${e.message}`); }

            // Strategy 2: synthetic ClipboardEvent
            if (!filled) {
              try {
                await loc.evaluate((el, text) => {
                  el.innerText = '';
                  el.focus();
                  const dt = new DataTransfer();
                  dt.setData('text/plain', text);
                  el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
                }, fillValue);
                await page.waitForTimeout(200);
                const content = await loc.evaluate((el) => (el).innerText.trim());
                if (content.length > 0) { filled = true; logger.push('[fill] Strategy 2 (synthetic) succeeded'); }
              } catch (e) { logger.push(`[fill] Strategy 2 failed: ${e.message}`); }
            }

            // Strategy 3: direct DOM insertion
            if (!filled) {
              logger.push('[fill] Using Strategy 3 (direct DOM)');
              await loc.evaluate((el, text) => {
                el.innerText = text;
                el.dispatchEvent(new Event('input', { bubbles: true }));
              }, fillValue);
            }
          } else {
            await loc.evaluate((el) => { el.innerText = ''; el.focus(); });
            await loc.type(fillValue, { delay: 20 });
          }
        } else {
          try {
            await loc.fill(step.value || '', { timeout: 5000 });
          } catch {
            logger.push('[fill] fill() failed, fallback to click+type');
            await loc.click({ timeout: 3000 });
            await page.keyboard.press('Control+a');
            await loc.type(step.value || '', { delay: 20 });
          }
        }
        logger.push(`[fill] Filled: ${step.target}`);
        break;
      }

      case 'press': {
        const key = step.value || 'Enter';
        if (step.target) {
          let loc = await resolveFillTarget(page, step.target).catch(() => null);
          if (!loc) loc = await resolveTargetSafe(page, step.target);
          if (loc) {
            await ensureVisible(loc, step.target);
            await loc.press(key, { timeout: 8000 }).catch(async () => {
              await loc.click({ timeout: 3000 }).catch(() => {});
              await page.keyboard.press(key);
            });
            logger.push(`[press] Pressed: ${key} on ${step.target}`);
            break;
          }
        }
        await page.keyboard.press(key);
        logger.push(`[press] Pressed: ${key}`);
        break;
      }

      case 'hover': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.hover({ timeout: 10000 });
        logger.push(`[hover] Hovered: ${step.target}`);
        break;
      }

      case 'scroll': {
        const val = (step.value || step.target || '').toLowerCase();
        if (step.target && !/^(top|bottom|up|down|\d+)$/.test(val)) {
          const loc = await resolveTargetSafe(page, step.target) || await resolveTarget(page, step.target);
          logger.push(`[scroll] Scrolling to element: ${step.target}`);
          await loc.scrollIntoViewIfNeeded({ timeout: 10000 });
        } else if (val === 'top') {
          await page.evaluate(() => window.scrollTo(0, 0));
        } else if (val === 'bottom') {
          await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
        } else if (val === 'up') {
          await page.evaluate(() => window.scrollBy(0, -500));
        } else if (val === 'down') {
          await page.evaluate(() => window.scrollBy(0, 500));
        } else {
          await page.evaluate((y) => window.scrollBy(0, y), parseInt(val) || 500);
        }
        logger.push(`[scroll] Scrolled: ${val}`);
        break;
      }

      case 'select': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.selectOption(step.value || '', { timeout: 10000 });
        logger.push(`[select] Selected: ${step.value}`);
        break;
      }

      case 'upload': {
        const filePath = step.value || '';
        let fileInputLoc;
        if (!step.target) {
          fileInputLoc = page.locator('input[type="file"]').first();
        } else {
          const resolved = await resolveTarget(page, step.target);
          const isFileInput = await resolved.evaluate(
            (el) => el.tagName === 'INPUT' && el.type === 'file'
          ).catch(() => false);

          if (isFileInput) {
            fileInputLoc = resolved;
          } else {
            // Look for nearby input[type="file"]
            const nearbyFileInput = await resolved.evaluate((el) => {
              const parent = el.parentElement;
              if (!parent) return false;
              return !!parent.querySelector('input[type="file"]') ||
                     !!parent.parentElement?.querySelector('input[type="file"]');
            }).catch(() => false);

            if (nearbyFileInput) {
              fileInputLoc = resolved.locator('xpath=ancestor-or-self::*[1]//input[@type="file"]').first();
              const found = await fileInputLoc.count().catch(() => 0);
              if (!found) {
                fileInputLoc = resolved.locator('xpath=../input[@type="file"]').first();
              }
            } else {
              fileInputLoc = page.locator('input[type="file"]').first();
            }
          }
        }
        await fileInputLoc.setInputFiles(filePath, { timeout: 10000 });
        logger.push(`[upload] Uploaded: ${filePath}`);
        break;
      }

      case 'back': {
        await page.goBack({ waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(500);
        logger.push('[back] Navigated back');
        break;
      }

      case 'refresh': {
        await page.reload({ waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(500);
        logger.push('[refresh] Reloaded page');
        break;
      }

      case 'clear': {
        const loc = await resolveFillTarget(page, step.target);
        await loc.fill('', { timeout: 5000 }).catch(async () => {
          await loc.click({ timeout: 3000 });
          await page.keyboard.press('Control+a');
          await page.keyboard.press('Backspace');
        });
        logger.push(`[clear] Cleared: ${step.target}`);
        break;
      }

      case 'wait': {
        const ms = Math.min(parseInt(step.value || '2000') || 2000, 10000);
        await page.waitForTimeout(ms);
        logger.push(`[wait] Waited: ${ms}ms`);
        break;
      }

      case 'wait_for': {
        const target = cleanTargetText(step.target);
        const timeout = Math.min(parseInt(step.value || '') || 30000, 60000);
        if (isSelectorLike(target)) {
          await page.waitForSelector(target, { state: 'visible', timeout });
        } else {
          await page.getByText(target).waitFor({ state: 'visible', timeout });
        }
        logger.push(`[wait_for] Found: ${target}`);
        break;
      }

      case 'wait_for_state': {
        const targetState = (step.value || 'disabled').toLowerCase();
        const timeoutMs = parseInt(step.assertion?.expected || '') || 60000;
        const selector = step.target;
        logger.push(`[wait_for_state] Waiting for "${selector}" to become ${targetState} (timeout=${timeoutMs}ms)`);

        const loc = await resolveTarget(page, selector);
        const startTs = Date.now();
        const pollInterval = 500;
        let reached = false;

        while (Date.now() - startTs < timeoutMs) {
          let currentState;
          switch (targetState) {
            case 'disabled': currentState = !(await loc.isEnabled().catch(() => true)); break;
            case 'enabled': currentState = await loc.isEnabled().catch(() => false); break;
            case 'visible': currentState = await loc.isVisible().catch(() => false); break;
            case 'hidden': currentState = !(await loc.isVisible().catch(() => true)); break;
            default: throw new Error(`wait_for_state: 不支持的状态 "${targetState}"`);
          }
          if (currentState) {
            logger.push(`[wait_for_state] "${selector}" became ${targetState} after ${Date.now() - startTs}ms`);
            reached = true;
            break;
          }
          await page.waitForTimeout(pollInterval);
        }

        if (!reached) {
          if (step.optional) {
            logger.push(`[wait_for_state] WARNING: "${selector}" did not reach ${targetState} within ${timeoutMs}ms (optional, continuing)`);
          } else {
            throw new Error(`wait_for_state: "${selector}" 在 ${timeoutMs}ms 内未变为 ${targetState}`);
          }
        }
        break;
      }

      case 'screenshot': {
        const file = `step-${index + 1}-${Date.now()}.png`;
        const screenshotPath = path.join(screenshotDir, file);
        fs.mkdirSync(screenshotDir, { recursive: true });
        await page.screenshot({ path: screenshotPath, fullPage: false });
        logger.push(`[screenshot] Saved: ${screenshotPath}`);
        break;
      }

      case 'assert': {
        const result = await executeAssertion(page, step.assertion, capturedRequests, logger);
        if (!result.passed && !step.optional) {
          throw new Error(`Assertion failed: ${step.assertion?.type} - expected "${step.assertion?.expected}", actual: "${result.actual}"`);
        }
        if (!result.passed && step.optional) {
          logger.push(`[assert] OPTIONAL FAILED: ${step.assertion?.type} - ${result.actual}`);
        } else {
          logger.push(`[assert] ${step.assertion?.type}: passed`);
        }
        break;
      }

      default:
        throw new Error(`Unsupported action: ${step.action}`);
    }

    // Post-step settling
    await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {});
    await page.waitForTimeout(500);

    // Variable capture
    if (step['capture']) {
      const varName = step['capture'];
      if (step.action === 'fill' && step.value) {
        stepContext.set(varName, step.value);
      } else if (step.target) {
        stepContext.set(varName, step.target);
      }
    }

    return {
      stepIndex: index, action: step.action, target: step.target, value: step.value,
      passed: true, durationMs: Date.now() - start,
    };
  } catch (err) {
    // Failure screenshot
    if (screenshotDir) {
      try {
        const file = `fail-step-${index + 1}-${Date.now()}.png`;
        await page.screenshot({ path: path.join(screenshotDir, file), fullPage: false });
      } catch {}
    }

    logger.push(`[step FAILED] ${step.action} - ${err.message}`);
    return {
      stepIndex: index, action: step.action, target: step.target, value: step.value,
      passed: false, error: err.message, durationMs: Date.now() - start,
    };
  }
}

// ── Plan Execution ─────────────────────────────────────────────────────────

async function executePlan(page, plan, logger) {
  const results = [];
  const stepContext = new Map();
  const capturedRequests = [];
  const reportDir = process.env.REPORT_DIR || path.join(__dirname, '..', '..', 'reports');
  const screenshotDir = path.join(reportDir, 'screenshots');

  // Setup request/response capture
  const pendingRequests = new Map();
  const onRequest = (req) => {
    const url = req.url();
    if (url.startsWith('data:') || url.endsWith('.png') || url.endsWith('.jpg') || url.endsWith('.css')) return;
    pendingRequests.set(req, { url, method: req.method(), startTime: Date.now() });
  };
  const onResponse = async (resp) => {
    const req = resp.request();
    const pending = pendingRequests.get(req);
    if (!pending) return;
    pendingRequests.delete(req);
    const contentType = resp.headers()['content-type'] || '';
    if (!contentType.includes('json') && !contentType.includes('text')) return;
    let bodySnippet;
    try {
      const body = await resp.text();
      bodySnippet = body.substring(0, 500);
    } catch {}
    capturedRequests.push({
      url: pending.url, method: pending.method, status: resp.status(),
      bodySnippet, durationMs: Date.now() - pending.startTime,
    });
  };
  page.on('request', onRequest);
  page.on('response', onResponse);

  // Collect hover-only targets from steps
  const hoverOnlyTargets = new Set();
  if (plan.steps) {
    for (const step of plan.steps) {
      if (step.hoverOnly || (step.assertion?.hoverOnly)) {
        if (step.target) hoverOnlyTargets.add(step.target);
      }
    }
  }

  // Navigate if first step is navigate
  if (plan.steps.length > 0 && plan.steps[0].action === 'navigate') {
    const navUrl = plan.steps[0].value || plan.target_url;
    logger.push(`[navigate] Going to: ${navUrl}`);
    await page.goto(navUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 12000 }).catch(() => {});
    await page.waitForTimeout(500);
    logger.push(`[navigate] Loaded: ${page.url()}`);
  }

  let stepFailed = false;
  for (let i = 0; i < plan.steps.length; i++) {
    const step = plan.steps[i];

    // Cascade skip after failure
    if (stepFailed && !step.optional) {
      results.push({
        stepIndex: i, action: step.action, target: step.target, value: step.value,
        passed: false, skipped: true, reason: '前置步骤失败，已跳过', durationMs: 0,
      });
      continue;
    }

    logger.push(`[step ${i + 1}/${plan.steps.length}] ${step.action} ${step.target || ''}`);
    const result = await executeStep(page, step, i, logger, stepContext, hoverOnlyTargets, capturedRequests, screenshotDir);
    results.push(result);

    if (!result.passed && !result.skipped && !step.optional) {
      stepFailed = true;
      logger.push(`[step ${i + 1} FAILED] Non-optional step failed, aborting plan`);
    }
  }

  // Final screenshot
  try {
    const finalFile = `final-${Date.now()}.png`;
    await page.screenshot({ path: path.join(screenshotDir, finalFile), fullPage: false });
  } catch {}

  // Cleanup listeners
  page.off('request', onRequest);
  page.off('response', onResponse);

  return results;
}

// ── Report Generation ──────────────────────────────────────────────────────




// ── Main Entry Point ───────────────────────────────────────────────────────

async function main() {
  const opts = parseArgs();
  const logger = new SocketLogger();

  logger.push('=== ChatQA Executor Started ===');
  logger.push(`Spec file: ${opts.specFile}`);
  logger.push(`Variables: ${JSON.stringify(opts.variables)}`);

  let spec;
  try {
    spec = loadSpec(opts.specFile);
  } catch (err) {
    logger.push(`Failed to load spec: ${err.message}`);
    process.exit(1);
  }

  spec = resolveVariables(spec, opts.variables);

  let scenarios;
  if (spec.scenarios && Array.isArray(spec.scenarios)) {
    scenarios = spec.scenarios;
  } else if (spec.scenario_name && spec.steps) {
    scenarios = [{
      scenario_name: spec.scenario_name,
      plans: [{
        target_url: spec.target_url || '',
        description: spec.description || spec.scenario_name,
        steps: spec.steps,
      }],
    }];
  } else {
    logger.push('Invalid spec format: expected scenarios array or single case with scenario_name and steps');
    process.exit(1);
  }

  logger.push(`Loaded ${scenarios.length} scenarios`);
  logger.push(`[auth] Auth state: ${AUTH_STATE.cookies.length} cookies, ${AUTH_STATE.origins.length} origins`);

  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const allResults = [];

  try {
    for (const scenario of scenarios) {
      logger.push(`[scenario] ${scenario.scenario_name}`);

      const context = await browser.newContext({
        storageState: AUTH_STATE,
      });
      const page = await context.newPage();

      try {
        for (const plan of scenario.plans) {
          logger.push(`[plan] ${plan.description}`);

          const stepResults = await executePlan(page, plan, logger);
          const passed = stepResults.filter(r => r.passed).length;
          const failed = stepResults.filter(r => !r.passed).length;

          logger.push(`[plan done] ${plan.description} - passed: ${passed}, failed: ${failed}`);

          allResults.push({
            scenario: scenario.scenario_name,
            plan: plan.description,
            steps: stepResults,
            passed,
            failed,
          });
        }
      } finally {
        await context.close();
      }
    }
  } finally {
    await browser.close();
  }

  const reportDir = process.env.REPORT_DIR || path.join(__dirname, '..', '..', 'reports');
  fs.mkdirSync(reportDir, { recursive: true });

  // Save results as JSON for backend processing
  const resultsPath = path.join(reportDir, 'results.json');
  fs.writeFileSync(resultsPath, JSON.stringify({
    totalPassed: allResults.reduce((sum, r) => sum + r.passed, 0),
    totalFailed: allResults.reduce((sum, r) => sum + r.failed, 0),
    scenarios: allResults,
  }, null, 2));
  logger.push(`Results saved: ${resultsPath}`);

  const totalPassed = allResults.reduce((sum, r) => sum + r.passed, 0);
  const totalFailed = allResults.reduce((sum, r) => sum + r.failed, 0);
  logger.push(`=== Execution Complete: ${totalPassed} passed, ${totalFailed} failed ===`);

  logger.close();

  if (totalFailed > 0) {
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
