/**
 * chatqa-executor - Main entry point for TestHub Runner
 *
 * This script executes ChatQA test plans received from the TestHub Server.
 * It connects to a Unix socket for log streaming and produces HTML reports.
 *
 * Usage:
 *   node src/index.js -f spec.yaml -p '{"var1":"value1"}'
 *
 * Environment:
 *   LOCAL_SOCKET_PATH - Path to Unix socket for log streaming
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const net = require('net');
const { XMLParser } = require('fast-xml-parser');

// ── CLI Argument Parsing ───────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  const opts = { specFile: 'spec.yaml', variables: {} };

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-f' && args[i + 1]) {
      opts.specFile = args[++i];
    } else if (args[i] === '-p' && args[i + 1]) {
      try {
        opts.variables = JSON.parse(args[++i]);
      } catch (e) {
        console.error(`Failed to parse variables JSON: ${e.message}`);
        process.exit(1);
      }
    }
  }

  return opts;
}

// ── Socket Logger ──────────────────────────────────────────────────────────

class SocketLogger {
  constructor(socketPath) {
    this.socketPath = socketPath || process.env.LOCAL_SOCKET_PATH;
    this.connected = false;
    this.queue = [];
    this._connect();
  }

  _connect() {
    if (!this.socketPath) {
      this.connected = true; // No socket, just log
      return;
    }
    this.client = net.createConnection({ path: this.socketPath }, () => {
      this.connected = true;
      this._flush();
    });
    this.client.on('error', () => {});
  }

  _flush() {
    while (this.queue.length > 0 && this.connected) {
      const msg = this.queue.shift();
      this.client.write(msg + '\n');
    }
  }

  push(message) {
    const ts = new Date().toISOString();
    const log = `[${ts}] ${message}`;
    console.log(log);
    if (this.connected && this.client) {
      this.client.write(log + '\n');
    }
  }

  close() {
    if (this.client) {
      this.client.end();
    }
  }
}

// ── Spec Loading ───────────────────────────────────────────────────────────

function loadSpec(specFile) {
  const content = fs.readFileSync(specFile, 'utf-8');
  // Spec from database is JSON format: { scenarios: [...] }
  return JSON.parse(content);
}

// ── Variable Substitution ──────────────────────────────────────────────────

function resolveVariables(obj, variables) {
  if (typeof obj === 'string') {
    return obj.replace(/\$\{(\w+)\}/g, (_, key) => {
      return variables[key] !== undefined ? variables[key] : _;
    });
  }
  if (Array.isArray(obj)) {
    return obj.map(item => resolveVariables(item, variables));
  }
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      result[k] = resolveVariables(v, variables);
    }
    return result;
  }
  return obj;
}

// ── Target Resolution ──────────────────────────────────────────────────────

async function resolveTarget(page, target) {
  // Try as CSS selector
  try {
    const loc = page.locator(target);
    const count = await loc.count();
    if (count === 1) return loc;
    if (count > 1) {
      for (let i = 0; i < count; i++) {
        const nth = loc.nth(i);
        if (await nth.isVisible().catch(() => false)) return nth;
      }
      return loc.first();
    }
  } catch {
    // Not valid CSS, try other strategies
  }

  // Try data-testid
  if (target.startsWith('[data-testid="') || target.startsWith('[data-testid=')) {
    const testId = target.match(/\[data-testid=["']?([^"'\]]+)["']?\]/)?.[1];
    if (testId) return page.getByTestId(testId);
  }

  // Try text match
  return page.getByText(target);
}

async function resolveFillTarget(page, target) {
  const loc = await resolveTarget(page, target);

  const isFillable = await loc.evaluate((el) => {
    const tag = el.tagName.toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' ||
      el.isContentEditable || el.getAttribute('contenteditable') === 'true';
  }).catch(() => false);

  if (isFillable) return loc;

  const child = loc.locator('input, textarea, select, [contenteditable]').first();
  if (await child.count().catch(() => 0) > 0) return child;

  return loc;
}

async function ensureVisible(loc, target) {
  await loc.waitFor({ state: 'visible', timeout: 5000 }).catch(() => {
    loc.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
  });
}

// ── Assertion Execution ────────────────────────────────────────────────────

async function executeAssertion(page, assertion) {
  if (!assertion) return { passed: true, actual: '' };

  switch (assertion.type) {
    case 'visible':
    case 'text_contains':
    case 'text_equals':
    case 'exists': {
      const target = cleanTarget(assertion.expected || '');
      if (isSelectorLike(target)) {
        await page.waitForSelector(target, { state: 'visible', timeout: 10000 });
      } else {
        await page.getByText(target).waitFor({ state: 'visible', timeout: 10000 });
      }
      return { passed: true, actual: assertion.expected };
    }

    case 'not_visible': {
      const target = cleanTarget(assertion.expected || '');
      if (isSelectorLike(target)) {
        await page.waitForSelector(target, { state: 'hidden', timeout: 10000 });
      } else {
        await page.getByText(target).waitFor({ state: 'hidden', timeout: 10000 });
      }
      return { passed: true, actual: 'hidden' };
    }

    case 'url_contains': {
      const url = page.url();
      if (url.includes(assertion.expected || '')) {
        return { passed: true, actual: url };
      }
      return { passed: false, actual: url };
    }

    case 'href_exists': {
      const loc = page.locator(`a:has-text("${assertion.expected}")`);
      const count = await loc.count();
      if (count > 0) return { passed: true, actual: 'exists' };
      return { passed: false, actual: 'not found' };
    }

    case 'href_not_exists': {
      const loc = page.locator(`a:has-text("${assertion.expected}")`);
      const count = await loc.count();
      if (count === 0) return { passed: true, actual: 'not exists' };
      return { passed: false, actual: 'exists' };
    }

    case 'count_gte': {
      const target = cleanTarget(assertion.expected || '');
      const [, selectorPart, countPart] = target.match(/(.*)\s*>=\s*(\d+)/) || [];
      if (selectorPart && countPart) {
        const count = await page.locator(selectorPart.trim()).count();
        if (count >= parseInt(countPart, 10)) {
          return { passed: true, actual: String(count) };
        }
        return { passed: false, actual: String(count) };
      }
      return { passed: true, actual: '' };
    }

    case 'text_equals': {
      const target = cleanTarget(assertion.expected || '');
      if (isSelectorLike(target)) {
        const text = await page.locator(target).textContent();
        return { passed: text === assertion.expected, actual: text || '' };
      }
      return { passed: true, actual: assertion.expected };
    }

    default:
      // For unsupported assertions (llm_judge, api_status, etc.), log and pass
      return { passed: true, actual: `unsupported type: ${assertion.type}` };
  }
}

function cleanTarget(target) {
  return target.replace(/^\[data-testid=["']?/, '').replace(/["']?\]$/, '')
    .replace(/^text=/, '').replace(/^aria=/, '').trim();
}

function isSelectorLike(target) {
  return target.startsWith('#') || target.startsWith('.') || target.startsWith('[') ||
    /^[a-z][\w-]*[>\s]/.test(target);
}

// ── Step Execution ─────────────────────────────────────────────────────────

async function executeStep(page, step, index, logger) {
  const start = Date.now();

  try {
    switch (step.action) {
      case 'navigate': {
        const url = step.value || step.target || '';
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.waitForLoadState('networkidle', { timeout: 12000 }).catch(() => {});
        logger.push(`[navigate] Loaded: ${page.url()}`);
        break;
      }

      case 'click': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.click({ timeout: 10000 });
        logger.push(`[click] Clicked: ${step.target}`);
        break;
      }

      case 'fill': {
        const loc = await resolveFillTarget(page, step.target);
        await ensureVisible(loc, step.target);

        const isEditable = await loc.evaluate((el) =>
          el.isContentEditable || el.getAttribute('contenteditable') === 'true'
        ).catch(() => false);

        if (isEditable) {
          await loc.click({ timeout: 5000 });
          await loc.evaluate((el, text) => {
            el.innerText = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
          }, step.value || '');
        } else {
          await loc.fill(step.value || '', { timeout: 10000 });
        }
        logger.push(`[fill] Filled: ${step.target}`);
        break;
      }

      case 'press': {
        const key = step.value || 'Enter';
        await page.keyboard.press(key);
        logger.push(`[press] Pressed: ${key}`);
        break;
      }

      case 'hover': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.hover({ timeout: 10000 });
        logger.push(`[hover] Hovered: ${step.target}`);
        break;
      }

      case 'scroll': {
        const val = (step.value || step.target || '').toLowerCase();
        if (val === 'top') await page.evaluate(() => window.scrollTo(0, 0));
        else if (val === 'bottom') await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
        else if (val === 'up') await page.evaluate(() => window.scrollBy(0, -500));
        else if (val === 'down') await page.evaluate(() => window.scrollBy(0, 500));
        else await page.evaluate((y) => window.scrollBy(0, y), parseInt(val) || 500);
        logger.push(`[scroll] Scrolled: ${val}`);
        break;
      }

      case 'select': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.selectOption(step.value || '', { timeout: 10000 });
        logger.push(`[select] Selected: ${step.value}`);
        break;
      }

      case 'upload': {
        const filePath = step.value || '';
        await page.locator('input[type="file"]').first().setInputFiles(filePath);
        logger.push(`[upload] Uploaded: ${filePath}`);
        break;
      }

      case 'back': {
        await page.goBack({ waitUntil: 'domcontentloaded' });
        logger.push('[back] Navigated back');
        break;
      }

      case 'refresh': {
        await page.reload({ waitUntil: 'domcontentloaded' });
        logger.push('[refresh] Reloaded page');
        break;
      }

      case 'clear': {
        const loc = await resolveFillTarget(page, step.target);
        await loc.fill('', { timeout: 5000 }).catch(async () => {
          await loc.click({ timeout: 3000 });
          await page.keyboard.press('Control+a');
          await page.keyboard.press('Backspace');
        });
        logger.push(`[clear] Cleared: ${step.target}`);
        break;
      }

      case 'wait': {
        const ms = Math.min(parseInt(step.value || '2000') || 2000, 10000);
        await page.waitForTimeout(ms);
        logger.push(`[wait] Waited: ${ms}ms`);
        break;
      }

      case 'wait_for': {
        const target = cleanTarget(step.target);
        const timeout = Math.min(parseInt(step.value || '') || 30000, 60000);
        if (isSelectorLike(target)) {
          await page.waitForSelector(target, { state: 'visible', timeout });
        } else {
          await page.getByText(target).waitFor({ state: 'visible', timeout });
        }
        logger.push(`[wait_for] Found: ${target}`);
        break;
      }

      case 'assert': {
        const result = await executeAssertion(page, step.assertion);
        if (!result.passed) {
          throw new Error(`Assertion failed: ${step.assertion?.type} - expected "${step.assertion?.expected}", actual: "${result.actual}"`);
        }
        logger.push(`[assert] ${step.assertion?.type}: passed`);
        break;
      }

      case 'screenshot': {
        logger.push('[screenshot] Captured');
        break;
      }

      default:
        throw new Error(`Unsupported action: ${step.action}`);
    }

    return {
      stepIndex: index,
      action: step.action,
      target: step.target,
      value: step.value,
      passed: true,
      durationMs: Date.now() - start,
    };
  } catch (err) {
    logger.push(`[step FAILED] ${step.action} - ${err.message}`);
    return {
      stepIndex: index,
      action: step.action,
      target: step.target,
      value: step.value,
      passed: false,
      error: err.message,
      durationMs: Date.now() - start,
    };
  }
}

// ── Plan Execution ─────────────────────────────────────────────────────────

async function executePlan(page, plan, logger) {
  const results = [];

  // Navigate if first step is navigate
  if (plan.steps.length > 0 && plan.steps[0].action === 'navigate') {
    const navUrl = plan.steps[0].value || plan.target_url;
    logger.push(`[navigate] Going to: ${navUrl}`);
    await page.goto(navUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 12000 }).catch(() => {});
    logger.push(`[navigate] Loaded: ${page.url()}`);
  }

  for (let i = 0; i < plan.steps.length; i++) {
    const step = plan.steps[i];
    logger.push(`[step ${i + 1}/${plan.steps.length}] ${step.action} ${step.target || ''}`);

    const result = await executeStep(page, step, i, logger);
    results.push(result);

    if (!result.passed && !step.optional) {
      logger.push(`[step ${i + 1} FAILED] Non-optional step failed, aborting plan`);
      break;
    }
  }

  return results;
}

// ── Report Generation ──────────────────────────────────────────────────────

function generateReport(allResults, reportDir) {
  fs.mkdirSync(reportDir, { recursive: true });

  let totalPassed = 0;
  let totalFailed = 0;
  let rows = '';

  for (const result of allResults) {
    for (const planResult of result.plans) {
      const passed = planResult.passed;
      const failed = planResult.failed;
      totalPassed += passed;
      totalFailed += failed;

      rows += `
        <tr class="${failed > 0 ? 'failed' : 'passed'}">
          <td>${result.scenario}</td>
          <td>${planResult.plan}</td>
          <td>${passed}</td>
          <td>${failed}</td>
          <td>${failed > 0 ? 'FAILED' : 'PASSED'}</td>
        </tr>`;

      for (const step of planResult.steps) {
        rows += `
          <tr class="step ${step.passed ? 'passed' : 'failed'}">
            <td colspan="2">&nbsp;&nbsp;Step ${step.stepIndex + 1}: ${step.action}${step.target ? ' → ' + step.target : ''}</td>
            <td colspan="2">${step.durationMs}ms</td>
            <td>${step.passed ? 'OK' : step.error || 'FAILED'}</td>
          </tr>`;
      }
    }
  }

  const total = totalPassed + totalFailed;
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>TestHub Execution Report</title>
<style>
body{font-family:system-ui,sans-serif;margin:2rem;background:#f5f5f5}
h1{color:#333}
.summary{display:flex;gap:1rem;margin:1rem 0}
.card{background:#fff;padding:1rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,.1)}
.card.passed{border-left:4px solid #28a745}
.card.failed{border-left:4px solid #dc3545}
table{width:100%;border-collapse:collapse;background:#fff;margin-top:1rem}
th,td{padding:.5rem 1rem;text-align:left;border-bottom:1px solid #eee}
th{background:#f8f9fa}
tr.passed{color:#28a745}
tr.failed{color:#dc3545}
tr.step{color:#666;font-size:.9em}
tr.step td:first-child{padding-left:2rem}
</style>
</head>
<body>
<h1>TestHub Execution Report</h1>
<div class="summary">
  <div class="card passed"><h3>${totalPassed}</h3><p>Passed</p></div>
  <div class="card failed"><h3>${totalFailed}</h3><p>Failed</p></div>
  <div class="card"><h3>${total}</h3><p>Total</p></div>
</div>
<table>
<thead><tr><th>Scenario</th><th>Plan</th><th>Passed</th><th>Failed</th><th>Status</th></tr></thead>
<tbody>${rows}</tbody>
</table>
</body>
</html>`;

  const reportPath = path.join(reportDir, 'index.html');
  fs.writeFileSync(reportPath, html);
  return reportPath;
}

// ── Main Entry Point ───────────────────────────────────────────────────────

async function main() {
  const opts = parseArgs();
  const logger = new SocketLogger();

  logger.push('=== ChatQA Executor Started ===');
  logger.push(`Spec file: ${opts.specFile}`);
  logger.push(`Variables: ${JSON.stringify(opts.variables)}`);

  // Load spec
  let spec;
  try {
    spec = loadSpec(opts.specFile);
  } catch (err) {
    logger.push(`Failed to load spec: ${err.message}`);
    process.exit(1);
  }

  // Resolve variables in spec
  spec = resolveVariables(spec, opts.variables);

  const scenarios = spec.scenarios || spec;
  if (!Array.isArray(scenarios)) {
    logger.push('Invalid spec format: expected array of scenarios');
    process.exit(1);
  }

  logger.push(`Loaded ${scenarios.length} scenarios`);

  // Launch browser
  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const allResults = [];

  try {
    for (const scenario of scenarios) {
      logger.push(`[scenario] ${scenario.scenario_name}`);

      // Create isolated context per scenario
      const context = await browser.newContext();
      const page = await context.newPage();

      try {
        for (const plan of scenario.plans) {
          logger.push(`[plan] ${plan.description}`);

          const stepResults = await executePlan(page, plan, logger);
          const passed = stepResults.filter(r => r.passed).length;
          const failed = stepResults.filter(r => !r.passed).length;

          logger.push(`[plan done] ${plan.description} - passed: ${passed}, failed: ${failed}`);

          allResults.push({
            scenario: scenario.scenario_name,
            plan: plan.description,
            steps: stepResults,
            passed,
            failed,
          });
        }
      } finally {
        await context.close();
      }
    }
  } finally {
    await browser.close();
  }

  // Generate report
  const reportDir = path.join(__dirname, '..', '..', 'reports');
  const reportPath = generateReport(allResults, reportDir);
  logger.push(`Report saved: ${reportPath}`);

  // Summary
  const totalPassed = allResults.reduce((sum, r) => sum + r.passed, 0);
  const totalFailed = allResults.reduce((sum, r) => sum + r.failed, 0);
  logger.push(`=== Execution Complete: ${totalPassed} passed, ${totalFailed} failed ===`);

  logger.close();

  // Exit with error code if any failures
  if (totalFailed > 0) {
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
