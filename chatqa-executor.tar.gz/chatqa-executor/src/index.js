/**
 * chatqa-executor - Main entry point for TestHub Runner
 *
 * This script executes ChatQA test plans received from the TestHub Server.
 * It connects to a Unix socket for log streaming and produces HTML reports.
 *
 * Usage:
 *   node src/index.js -f spec.yaml -p '{"var1":"value1"}'
 *
 * Environment:
 *   LOCAL_SOCKET_PATH - Path to Unix socket for log streaming
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const net = require('net');
const { XMLParser } = require('fast-xml-parser');
const pixelmatch = require('pixelmatch');
const { PNG } = require('pngjs');

// ── CLI Argument Parsing ───────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  const opts = { specFile: 'spec.yaml', variables: {} };

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-f' && args[i + 1]) {
      opts.specFile = args[++i];
    } else if (args[i] === '-p' && args[i + 1]) {
      try {
        opts.variables = JSON.parse(args[++i]);
      } catch (e) {
        console.error(`Failed to parse variables JSON: ${e.message}`);
        process.exit(1);
      }
    }
  }

  return opts;
}

// ── Socket Logger ──────────────────────────────────────────────────────────

class SocketLogger {
  constructor(socketPath) {
    this.socketPath = socketPath || process.env.LOCAL_SOCKET_PATH;
    this.connected = false;
    this.queue = [];
    this._connect();
  }

  _connect() {
    if (!this.socketPath) {
      this.connected = true;
      return;
    }
    this.client = net.createConnection({ path: this.socketPath }, () => {
      this.connected = true;
      this._flush();
    });
    this.client.on('error', () => {});
  }

  _flush() {
    while (this.queue.length > 0 && this.connected) {
      const msg = this.queue.shift();
      this.client.write(msg + '\n');
    }
  }

  push(message) {
    const ts = new Date().toISOString();
    const log = `[${ts}] ${message}`;
    console.log(log);
    if (this.connected && this.client) {
      this.client.write(log + '\n');
    }
  }

  close() {
    if (this.client) {
      this.client.end();
    }
  }
}

// ── Spec Loading ───────────────────────────────────────────────────────────

function loadSpec(specFile) {
  const content = fs.readFileSync(specFile, 'utf-8');
  return JSON.parse(content);
}

// ── Variable Substitution ──────────────────────────────────────────────────

function resolveVariables(obj, variables) {
  if (typeof obj === 'string') {
    return obj.replace(/\$\{(\w+)\}/g, (_, key) => {
      return variables[key] !== undefined ? variables[key] : _;
    });
  }
  if (Array.isArray(obj)) {
    return obj.map(item => resolveVariables(item, variables));
  }
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      result[k] = resolveVariables(v, variables);
    }
    return result;
  }
  return obj;
}

// ── Unicode Cleaning ───────────────────────────────────────────────────────

function cleanTargetText(target) {
  return target
    .replace(/[\u2318\u21E7\u2325\u2303\u23CE\u2190\u2191\u2192\u2193\u238B\u2326\u232B\u21A9]/g, '')
    .replace(/[\n\r\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function escapeCssAttributeValue(value) {
  return (value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

// ── Target Resolution ──────────────────────────────────────────────────────

async function resolveTarget(page, target) {
  target = cleanTargetText(target);
  const attrSafe = escapeCssAttributeValue(target);

  // 1. XPath expression
  if (/^\/\//.test(target) || /^\/[a-zA-Z*]/.test(target)) {
    try {
      const loc = page.locator(`xpath=${target}`);
      if ((await loc.count().catch(() => 0)) >= 1) {
        const first = loc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 2. CSS selector
  if (/^[a-z][\w-]*(\[|\.|\#| |>|,|:)/i.test(target) || /^\[/.test(target) || /^\./.test(target) || /^#/.test(target)) {
    try {
      const loc = page.locator(target);
      if ((await loc.count().catch(() => 0)) >= 1) {
        const first = loc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 3. data-testid
  try {
    const testIdLoc = page.locator(`[data-testid="${attrSafe}"]`);
    if ((await testIdLoc.count().catch(() => 0)) >= 1) {
      const first = testIdLoc.first();
      if (await first.isVisible().catch(() => false)) return first;
    }
  } catch {}

  // 4. name attribute
  try {
    const nameLoc = page.locator(`[name="${attrSafe}"]`);
    if ((await nameLoc.count().catch(() => 0)) >= 1) {
      const first = nameLoc.first();
      if (await first.isVisible().catch(() => false)) return first;
    }
  } catch {}

  // 5. href matching
  if ((target.startsWith('/') && !target.startsWith('//')) || target.startsWith('http')) {
    try {
      const hrefLoc = page.locator(`a[href*="${attrSafe}"]`);
      const count = await hrefLoc.count().catch(() => 0);
      if (count === 1) {
        const first = hrefLoc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 6. Attribute expressions: aria-label="..." etc.
  const attrMatch = target.match(/^(aria-label|aria-labelledby|title|name|placeholder|role)\s*=\s*"?([^"]+)"?$/i);
  if (attrMatch) {
    const [, attr, value] = attrMatch;
    const sel = `[${attr}="${escapeCssAttributeValue(value)}"]`;
    try {
      const loc = page.locator(sel);
      if ((await loc.count().catch(() => 0)) >= 1) {
        const first = loc.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
    // Try contains
    const selContains = `[${attr}*="${escapeCssAttributeValue(value)}" i]`;
    try {
      const loc = page.locator(selContains);
      if ((await loc.count().catch(() => 0)) >= 1) {
        return loc.first();
      }
    } catch {}
  }

  // 7. Semantic roles - exact matches
  const semanticStrategies = [
    () => page.getByRole('button', { name: target, exact: true }),
    () => page.getByRole('link', { name: target, exact: true }),
    () => page.getByRole('textbox', { name: target, exact: true }),
    () => page.getByRole('checkbox', { name: target, exact: true }),
    () => page.getByRole('menuitem', { name: target, exact: true }),
    () => page.getByLabel(target, { exact: true }),
    () => page.getByPlaceholder(target, { exact: true }),
    () => page.locator(`[contenteditable]:text-is("${attrSafe}")`),
    () => page.getByText(target, { exact: true }),
  ];

  for (const strategy of semanticStrategies) {
    try {
      const locator = strategy();
      const count = await locator.count();
      if (count === 1) {
        const first = locator.first();
        if (await first.isVisible().catch(() => false)) return first;
      }
    } catch {}
  }

  // 8. Fuzzy text match (only if unique)
  try {
    const textLoc = page.getByText(target, { exact: false });
    const count = await textLoc.count();
    if (count === 1) {
      const first = textLoc.first();
      if (await first.isVisible().catch(() => false)) return first;
    }
  } catch {}

  throw new Error(`Cannot resolve target "${target}"`);
}

async function resolveTargetSafe(page, target) {
  try {
    return await resolveTarget(page, target);
  } catch {
    return null;
  }
}

async function resolveFillTarget(page, target) {
  const cleanTarget = cleanTargetText(target);
  const FILLABLE_TAGS = new Set(['input', 'textarea', 'select']);

  // Native fillable elements
  const fillSelectors = [
    () => page.getByRole('textbox', { name: cleanTarget }),
    () => page.getByLabel(cleanTarget),
    () => page.getByPlaceholder(cleanTarget),
    () => page.locator(`input[name*="${cleanTarget.replace(/"/g, '\\"')}" i]`),
    () => page.locator(`textarea[placeholder*="${cleanTarget.replace(/"/g, '\\"')}" i]`),
  ];

  for (const strategy of fillSelectors) {
    try {
      const locator = strategy();
      const count = await locator.count();
      if (count < 1) continue;
      for (let ci = 0; ci < Math.min(count, 5); ci++) {
        const el = locator.nth(ci);
        const info = await el.evaluate((e) => ({
          tag: e.tagName.toLowerCase(),
          visible: e.offsetParent !== null,
        })).catch(() => ({ tag: '?', visible: true }));

        if (info.visible && FILLABLE_TAGS.has(info.tag)) return el;
      }
    } catch { continue; }
  }

  // Contenteditable elements
  const ceSelectors = [
    `[contenteditable="true"][aria-label*="${cleanTarget.replace(/"/g, '\\"')}" i]`,
    `[contenteditable="true"][placeholder*="${cleanTarget.replace(/"/g, '\\"')}" i]`,
    '[contenteditable="true"]',
    '[contenteditable=""]',
  ];
  for (const sel of ceSelectors) {
    try {
      const loc = page.locator(sel);
      const count = await loc.count();
      if (count < 1) continue;
      for (let ci = 0; ci < Math.min(count, 3); ci++) {
        const el = loc.nth(ci);
        const vis = await el.evaluate((e) => {
          const rect = e.getBoundingClientRect();
          return rect.width > 0 && rect.height > 0;
        }).catch(() => false);
        if (vis) return el;
      }
    } catch { continue; }
  }

  // Fallback
  return resolveTarget(page, target);
}

async function ensureVisible(loc, target) {
  await loc.waitFor({ state: 'visible', timeout: 5000 }).catch(() => {
    loc.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
  });
}

// ── Assertion Execution ────────────────────────────────────────────────────

async function executeAssertion(page, assertion, capturedRequests = []) {
  if (!assertion) return { passed: true, actual: '' };

  switch (assertion.type) {
    case 'visible':
    case 'text_contains':
    case 'text_equals':
    case 'exists': {
      const target = cleanTargetText(assertion.expected || '');
      if (isSelectorLike(target)) {
        await page.waitForSelector(target, { state: 'visible', timeout: 10000 });
      } else {
        await page.getByText(target).waitFor({ state: 'visible', timeout: 10000 });
      }
      return { passed: true, actual: assertion.expected };
    }

    case 'not_visible': {
      const target = cleanTargetText(assertion.expected || '');
      if (isSelectorLike(target)) {
        await page.waitForSelector(target, { state: 'hidden', timeout: 10000 });
      } else {
        await page.getByText(target).waitFor({ state: 'hidden', timeout: 10000 });
      }
      return { passed: true, actual: 'hidden' };
    }

    case 'not_empty': {
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert not_empty 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const text = await loc.textContent().catch(() => '') || '';
      const trimmed = text.trim();
      return { passed: trimmed.length > 0, actual: trimmed.length > 0 ? `有内容: "${trimmed.substring(0, 80)}"` : '内容为空' };
    }

    case 'enabled': {
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert enabled 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const isEnabled = await loc.isEnabled().catch(() => false);
      const isVisible = await loc.isVisible().catch(() => false);
      if (!isVisible) return { passed: false, actual: `"${searchKey}" 不可见` };
      return { passed: isEnabled, actual: isEnabled ? `"${searchKey}" 可用` : `"${searchKey}" 已禁用` };
    }

    case 'disabled': {
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert disabled 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const isEnabled = await loc.isEnabled().catch(() => false);
      const isVisible = await loc.isVisible().catch(() => false);
      if (!isVisible) return { passed: false, actual: `"${searchKey}" 不可见` };
      return { passed: !isEnabled, actual: !isEnabled ? `"${searchKey}" 已禁用` : `"${searchKey}" 仍可用` };
    }

    case 'attribute_contains': {
      const expectedRaw = assertion.expected || '';
      const eqIndex = expectedRaw.indexOf('=');
      if (eqIndex < 0) return { passed: false, actual: 'attribute_contains expected 格式应为 "attr=value"' };
      const attrName = expectedRaw.substring(0, eqIndex).trim();
      const attrExpected = expectedRaw.substring(eqIndex + 1).trim();
      const searchKey = cleanTargetText(assertion.expected || '');
      if (!searchKey) return { passed: false, actual: 'assert attribute_contains 缺少 target' };
      const loc = await resolveTargetSafe(page, searchKey);
      if (!loc) return { passed: false, actual: `未找到 "${searchKey}"` };
      const attrValue = await loc.getAttribute(attrName).catch(() => null);
      if (attrValue === null) return { passed: false, actual: `"${searchKey}" 没有属性 "${attrName}"` };
      const contains = attrValue.includes(attrExpected);
      return { passed: contains, actual: contains ? `${attrName}="${attrValue.substring(0, 100)}" 包含 "${attrExpected}"` : `${attrName}="${attrValue.substring(0, 100)}" 不含 "${attrExpected}"` };
    }

    case 'url_contains': {
      const url = page.url();
      if (url.includes(assertion.expected || '')) {
        return { passed: true, actual: url };
      }
      return { passed: false, actual: url };
    }

    case 'href_exists': {
      const loc = page.locator(`a:has-text("${assertion.expected}")`);
      const count = await loc.count();
      return { passed: count > 0, actual: count > 0 ? 'exists' : 'not found' };
    }

    case 'href_not_exists': {
      const loc = page.locator(`a:has-text("${assertion.expected}")`);
      const count = await loc.count();
      return { passed: count === 0, actual: count === 0 ? 'not exists' : 'exists' };
    }

    case 'count_gte': {
      const target = cleanTargetText(assertion.expected || '');
      const match = target.match(/(.*)\s*>=\s*(\d+)/);
      if (match) {
        const [, selectorPart, countPart] = match;
        const count = await page.locator(selectorPart.trim()).count();
        return { passed: count >= parseInt(countPart, 10), actual: String(count) };
      }
      return { passed: true, actual: '' };
    }

    case 'api_status': {
      const urlPattern = assertion.api_url_pattern || assertion.expected || '';
      const expectedStatus = parseInt(assertion.expected || '200', 10);
      if (!urlPattern) return { passed: false, actual: 'api_status 缺少 api_url_pattern 或 target' };
      const matching = capturedRequests.filter(r => r.url.includes(urlPattern));
      if (matching.length === 0) return { passed: false, actual: `未捕获到匹配 "${urlPattern}" 的请求` };
      const last = matching[matching.length - 1];
      return { passed: last.status === expectedStatus, actual: `${last.method} ${last.url.substring(0, 100)} -> ${last.status}` };
    }

    case 'api_body_contains': {
      const urlPattern = assertion.api_url_pattern || assertion.expected || '';
      const expectedText = assertion.expected || '';
      if (!urlPattern) return { passed: false, actual: 'api_body_contains 缺少 api_url_pattern 或 target' };
      if (!expectedText) return { passed: false, actual: 'api_body_contains 缺少 expected' };
      const matching = capturedRequests.filter(r => r.url.includes(urlPattern));
      if (matching.length === 0) return { passed: false, actual: `未捕获到匹配 "${urlPattern}" 的请求` };
      const last = matching[matching.length - 1];
      const contains = (last.bodySnippet || '').includes(expectedText);
      return { passed: contains, actual: contains ? 'API 响应包含预期内容' : `API 响应不含预期内容 (前200: "${(last.bodySnippet || '').substring(0, 200)}")` };
    }

    default:
      return { passed: true, actual: `unsupported type: ${assertion.type}` };
  }
}

function isSelectorLike(target) {
  return target.startsWith('#') || target.startsWith('.') || target.startsWith('[') ||
    /^[a-z][\w-]*[>\s]/.test(target);
}

// ── Step Execution ─────────────────────────────────────────────────────────

async function executeStep(page, step, index, logger, stepContext, hoverOnlyTargets, capturedRequests, screenshotDir) {
  const start = Date.now();

  // Resolve ${varName} in target/value/assertion
  const resolveVars = (s) => {
    if (!s || typeof s !== 'string' || !s.includes('${')) return s;
    return s.replace(/\$\{(\w+)\}/g, (_m, name) => {
      const val = stepContext.get(name);
      return val !== undefined ? val : _m;
    });
  };
  step.target = resolveVars(step.target);
  step.value = resolveVars(step.value);
  if (step.assertion?.expected) {
    step.assertion.expected = resolveVars(step.assertion.expected);
  }

  // Skip flag
  if (step.skip) {
    return {
      stepIndex: index, action: step.action, target: step.target, value: step.value,
      passed: true, skipped: true, reason: step.skip === true ? '标记为跳过' : String(step.skip),
      durationMs: 0,
    };
  }

  // Auto-hover for hover-only elements before click/assert
  if ((step.action === 'click' || step.action === 'assert') && step.target && hoverOnlyTargets.size > 0) {
    const isHoverOnly = hoverOnlyTargets.has(step.target) ||
      Array.from(hoverOnlyTargets).some(ht => step.target.includes(ht) || ht.includes(step.target));
    if (isHoverOnly) {
      try {
        const hoverLoc = await resolveTargetSafe(page, step.target);
        if (hoverLoc && await hoverLoc.count() > 0) {
          logger.push(`[auto-hover] Hovering hover-only target "${step.target}"`);
          await hoverLoc.hover({ timeout: 8000 });
          await page.waitForTimeout(300);
        }
      } catch (e) {
        logger.push(`[auto-hover] Failed for "${step.target}": ${e.message}`);
      }
    }
  }

  try {
    switch (step.action) {
      case 'navigate': {
        const url = step.value || step.target || '';
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.waitForLoadState('networkidle', { timeout: 12000 }).catch(() => {});
        await page.waitForTimeout(500);
        logger.push(`[navigate] Loaded: ${page.url()}`);
        break;
      }

      case 'template': {
        // Template step: extract selector from templateName and resolve to actual element
        // templateName format: "点击「[data-testid=\"xxx\"]」" or "等待「selector」出现"
        const templateName = step.templateName || '';
        const selectorMatch = templateName.match(/["「]([^"」]+)["」]/);
        const extractedTarget = selectorMatch ? selectorMatch[1] : templateName;
        logger.push(`[template] templateId=${step.templateId}, resolved target: ${extractedTarget}`);

        // Try to resolve and interact with the element
        try {
          const loc = await resolveTargetSafe(page, extractedTarget);
          if (loc) {
            const isVisible = await loc.isVisible().catch(() => false);
            logger.push(`[template] Element "${extractedTarget}" visible: ${isVisible}`);
          } else {
            logger.push(`[template] Element "${extractedTarget}" not found on current page`);
          }
        } catch (e) {
          logger.push(`[template] Resolution warning: ${e.message}`);
        }
        break;
      }

      case 'click': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        const elInfo = await loc.evaluate((el) => ({
          tag: el.tagName.toLowerCase(),
          text: (el.textContent || '').trim().substring(0, 80),
        })).catch(() => ({ tag: '?', text: '' }));

        // Auto-convert to selectOption for <select>
        if (elInfo.tag === 'select' && step.value) {
          logger.push(`[click] <select> detected -> selectOption("${step.value}")`);
          await loc.selectOption(step.value, { timeout: 10000 });
        } else {
          await loc.click({ timeout: 10000 });
        }
        logger.push(`[click] Clicked: ${step.target}`);
        break;
      }

      case 'fill': {
        const loc = await resolveFillTarget(page, step.target);
        await ensureVisible(loc, step.target);
        const elInfo = await loc.evaluate((el) => ({
          tag: el.tagName.toLowerCase(),
          contentEditable: el.isContentEditable || el.getAttribute('contenteditable') === 'true',
        })).catch(() => ({ tag: '?', contentEditable: false }));

        const nativeFillable = ['input', 'textarea', 'select'].includes(elInfo.tag);
        if (nativeFillable) {
          await loc.fill(step.value || '', { timeout: 10000 });
        } else if (elInfo.contentEditable) {
          await loc.click({ timeout: 5000 });
          const fillValue = step.value || '';
          const needsClipboard = /[`\n\r\t]/.test(fillValue) || fillValue.length > 200;

          if (needsClipboard) {
            let filled = false;
            // Strategy 1: real clipboard paste
            try {
              await page.evaluate(async (text) => { await navigator.clipboard.writeText(text); }, fillValue);
              const modifier = process.platform === 'darwin' ? 'Meta' : 'Control';
              await page.keyboard.press(`${modifier}+v`);
              await page.waitForTimeout(300);
              const content = await loc.evaluate((el) => (el).innerText.trim());
              if (content.length > 0) { filled = true; logger.push('[fill] Strategy 1 (clipboard) succeeded'); }
            } catch (e) { logger.push(`[fill] Strategy 1 failed: ${e.message}`); }

            // Strategy 2: synthetic ClipboardEvent
            if (!filled) {
              try {
                await loc.evaluate((el, text) => {
                  el.innerText = '';
                  el.focus();
                  const dt = new DataTransfer();
                  dt.setData('text/plain', text);
                  el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
                }, fillValue);
                await page.waitForTimeout(200);
                const content = await loc.evaluate((el) => (el).innerText.trim());
                if (content.length > 0) { filled = true; logger.push('[fill] Strategy 2 (synthetic) succeeded'); }
              } catch (e) { logger.push(`[fill] Strategy 2 failed: ${e.message}`); }
            }

            // Strategy 3: direct DOM insertion
            if (!filled) {
              logger.push('[fill] Using Strategy 3 (direct DOM)');
              await loc.evaluate((el, text) => {
                el.innerText = text;
                el.dispatchEvent(new Event('input', { bubbles: true }));
              }, fillValue);
            }
          } else {
            await loc.evaluate((el) => { el.innerText = ''; el.focus(); });
            await loc.type(fillValue, { delay: 20 });
          }
        } else {
          try {
            await loc.fill(step.value || '', { timeout: 5000 });
          } catch {
            logger.push('[fill] fill() failed, fallback to click+type');
            await loc.click({ timeout: 3000 });
            await page.keyboard.press('Control+a');
            await loc.type(step.value || '', { delay: 20 });
          }
        }
        logger.push(`[fill] Filled: ${step.target}`);
        break;
      }

      case 'press': {
        const key = step.value || 'Enter';
        if (step.target) {
          let loc = await resolveFillTarget(page, step.target).catch(() => null);
          if (!loc) loc = await resolveTargetSafe(page, step.target);
          if (loc) {
            await ensureVisible(loc, step.target);
            await loc.press(key, { timeout: 8000 }).catch(async () => {
              await loc.click({ timeout: 3000 }).catch(() => {});
              await page.keyboard.press(key);
            });
            logger.push(`[press] Pressed: ${key} on ${step.target}`);
            break;
          }
        }
        await page.keyboard.press(key);
        logger.push(`[press] Pressed: ${key}`);
        break;
      }

      case 'hover': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.hover({ timeout: 10000 });
        logger.push(`[hover] Hovered: ${step.target}`);
        break;
      }

      case 'scroll': {
        const val = (step.value || step.target || '').toLowerCase();
        if (step.target && !/^(top|bottom|up|down|\d+)$/.test(val)) {
          const loc = await resolveTargetSafe(page, step.target) || await resolveTarget(page, step.target);
          logger.push(`[scroll] Scrolling to element: ${step.target}`);
          await loc.scrollIntoViewIfNeeded({ timeout: 10000 });
        } else if (val === 'top') {
          await page.evaluate(() => window.scrollTo(0, 0));
        } else if (val === 'bottom') {
          await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
        } else if (val === 'up') {
          await page.evaluate(() => window.scrollBy(0, -500));
        } else if (val === 'down') {
          await page.evaluate(() => window.scrollBy(0, 500));
        } else {
          await page.evaluate((y) => window.scrollBy(0, y), parseInt(val) || 500);
        }
        logger.push(`[scroll] Scrolled: ${val}`);
        break;
      }

      case 'select': {
        const loc = await resolveTarget(page, step.target);
        await ensureVisible(loc, step.target);
        await loc.selectOption(step.value || '', { timeout: 10000 });
        logger.push(`[select] Selected: ${step.value}`);
        break;
      }

      case 'upload': {
        const filePath = step.value || '';
        let fileInputLoc;
        if (!step.target) {
          fileInputLoc = page.locator('input[type="file"]').first();
        } else {
          const resolved = await resolveTarget(page, step.target);
          const isFileInput = await resolved.evaluate(
            (el) => el.tagName === 'INPUT' && el.type === 'file'
          ).catch(() => false);

          if (isFileInput) {
            fileInputLoc = resolved;
          } else {
            // Look for nearby input[type="file"]
            const nearbyFileInput = await resolved.evaluate((el) => {
              const parent = el.parentElement;
              if (!parent) return false;
              return !!parent.querySelector('input[type="file"]') ||
                     !!parent.parentElement?.querySelector('input[type="file"]');
            }).catch(() => false);

            if (nearbyFileInput) {
              fileInputLoc = resolved.locator('xpath=ancestor-or-self::*[1]//input[@type="file"]').first();
              const found = await fileInputLoc.count().catch(() => 0);
              if (!found) {
                fileInputLoc = resolved.locator('xpath=../input[@type="file"]').first();
              }
            } else {
              fileInputLoc = page.locator('input[type="file"]').first();
            }
          }
        }
        await fileInputLoc.setInputFiles(filePath, { timeout: 10000 });
        logger.push(`[upload] Uploaded: ${filePath}`);
        break;
      }

      case 'back': {
        await page.goBack({ waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(500);
        logger.push('[back] Navigated back');
        break;
      }

      case 'refresh': {
        await page.reload({ waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(500);
        logger.push('[refresh] Reloaded page');
        break;
      }

      case 'clear': {
        const loc = await resolveFillTarget(page, step.target);
        await loc.fill('', { timeout: 5000 }).catch(async () => {
          await loc.click({ timeout: 3000 });
          await page.keyboard.press('Control+a');
          await page.keyboard.press('Backspace');
        });
        logger.push(`[clear] Cleared: ${step.target}`);
        break;
      }

      case 'wait': {
        const ms = Math.min(parseInt(step.value || '2000') || 2000, 10000);
        await page.waitForTimeout(ms);
        logger.push(`[wait] Waited: ${ms}ms`);
        break;
      }

      case 'wait_for': {
        const target = cleanTargetText(step.target);
        const timeout = Math.min(parseInt(step.value || '') || 30000, 60000);
        if (isSelectorLike(target)) {
          await page.waitForSelector(target, { state: 'visible', timeout });
        } else {
          await page.getByText(target).waitFor({ state: 'visible', timeout });
        }
        logger.push(`[wait_for] Found: ${target}`);
        break;
      }

      case 'wait_for_state': {
        const targetState = (step.value || 'disabled').toLowerCase();
        const timeoutMs = parseInt(step.assertion?.expected || '') || 60000;
        const selector = step.target;
        logger.push(`[wait_for_state] Waiting for "${selector}" to become ${targetState} (timeout=${timeoutMs}ms)`);

        const loc = await resolveTarget(page, selector);
        const startTs = Date.now();
        const pollInterval = 500;
        let reached = false;

        while (Date.now() - startTs < timeoutMs) {
          let currentState;
          switch (targetState) {
            case 'disabled': currentState = !(await loc.isEnabled().catch(() => true)); break;
            case 'enabled': currentState = await loc.isEnabled().catch(() => false); break;
            case 'visible': currentState = await loc.isVisible().catch(() => false); break;
            case 'hidden': currentState = !(await loc.isVisible().catch(() => true)); break;
            default: throw new Error(`wait_for_state: 不支持的状态 "${targetState}"`);
          }
          if (currentState) {
            logger.push(`[wait_for_state] "${selector}" became ${targetState} after ${Date.now() - startTs}ms`);
            reached = true;
            break;
          }
          await page.waitForTimeout(pollInterval);
        }

        if (!reached) {
          if (step.optional) {
            logger.push(`[wait_for_state] WARNING: "${selector}" did not reach ${targetState} within ${timeoutMs}ms (optional, continuing)`);
          } else {
            throw new Error(`wait_for_state: "${selector}" 在 ${timeoutMs}ms 内未变为 ${targetState}`);
          }
        }
        break;
      }

      case 'screenshot': {
        const file = `step-${index + 1}-${Date.now()}.png`;
        const screenshotPath = path.join(screenshotDir, file);
        fs.mkdirSync(screenshotDir, { recursive: true });
        await page.screenshot({ path: screenshotPath, fullPage: false });
        logger.push(`[screenshot] Saved: ${screenshotPath}`);
        break;
      }

      case 'assert': {
        const result = await executeAssertion(page, step.assertion, capturedRequests);
        if (!result.passed && !step.optional) {
          throw new Error(`Assertion failed: ${step.assertion?.type} - expected "${step.assertion?.expected}", actual: "${result.actual}"`);
        }
        if (!result.passed && step.optional) {
          logger.push(`[assert] OPTIONAL FAILED: ${step.assertion?.type} - ${result.actual}`);
        } else {
          logger.push(`[assert] ${step.assertion?.type}: passed`);
        }
        break;
      }

      default:
        throw new Error(`Unsupported action: ${step.action}`);
    }

    // Post-step settling
    await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {});
    await page.waitForTimeout(500);

    // Variable capture
    if (step['capture']) {
      const varName = step['capture'];
      if (step.action === 'fill' && step.value) {
        stepContext.set(varName, step.value);
      } else if (step.target) {
        stepContext.set(varName, step.target);
      }
    }

    return {
      stepIndex: index, action: step.action, target: step.target, value: step.value,
      passed: true, durationMs: Date.now() - start,
    };
  } catch (err) {
    // Failure screenshot
    if (screenshotDir) {
      try {
        const file = `fail-step-${index + 1}-${Date.now()}.png`;
        await page.screenshot({ path: path.join(screenshotDir, file), fullPage: false });
      } catch {}
    }

    logger.push(`[step FAILED] ${step.action} - ${err.message}`);
    return {
      stepIndex: index, action: step.action, target: step.target, value: step.value,
      passed: false, error: err.message, durationMs: Date.now() - start,
    };
  }
}

// ── Plan Execution ─────────────────────────────────────────────────────────

async function executePlan(page, plan, logger) {
  const results = [];
  const stepContext = new Map();
  const capturedRequests = [];
  const screenshotDir = path.join(__dirname, '..', '..', 'screenshots');

  // Setup request/response capture
  const pendingRequests = new Map();
  const onRequest = (req) => {
    const url = req.url();
    if (url.startsWith('data:') || url.endsWith('.png') || url.endsWith('.jpg') || url.endsWith('.css')) return;
    pendingRequests.set(req, { url, method: req.method(), startTime: Date.now() });
  };
  const onResponse = async (resp) => {
    const req = resp.request();
    const pending = pendingRequests.get(req);
    if (!pending) return;
    pendingRequests.delete(req);
    const contentType = resp.headers()['content-type'] || '';
    if (!contentType.includes('json') && !contentType.includes('text')) return;
    let bodySnippet;
    try {
      const body = await resp.text();
      bodySnippet = body.substring(0, 500);
    } catch {}
    capturedRequests.push({
      url: pending.url, method: pending.method, status: resp.status(),
      bodySnippet, durationMs: Date.now() - pending.startTime,
    });
  };
  page.on('request', onRequest);
  page.on('response', onResponse);

  // Collect hover-only targets from steps
  const hoverOnlyTargets = new Set();
  if (plan.steps) {
    for (const step of plan.steps) {
      if (step.hoverOnly || (step.assertion?.hoverOnly)) {
        if (step.target) hoverOnlyTargets.add(step.target);
      }
    }
  }

  // Navigate if first step is navigate
  if (plan.steps.length > 0 && plan.steps[0].action === 'navigate') {
    const navUrl = plan.steps[0].value || plan.target_url;
    logger.push(`[navigate] Going to: ${navUrl}`);
    await page.goto(navUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 12000 }).catch(() => {});
    await page.waitForTimeout(500);
    logger.push(`[navigate] Loaded: ${page.url()}`);
  }

  let stepFailed = false;
  for (let i = 0; i < plan.steps.length; i++) {
    const step = plan.steps[i];

    // Cascade skip after failure
    if (stepFailed && !step.optional) {
      results.push({
        stepIndex: i, action: step.action, target: step.target, value: step.value,
        passed: false, skipped: true, reason: '前置步骤失败，已跳过', durationMs: 0,
      });
      continue;
    }

    logger.push(`[step ${i + 1}/${plan.steps.length}] ${step.action} ${step.target || ''}`);
    const result = await executeStep(page, step, i, logger, stepContext, hoverOnlyTargets, capturedRequests, screenshotDir);
    results.push(result);

    if (!result.passed && !result.skipped && !step.optional) {
      stepFailed = true;
      logger.push(`[step ${i + 1} FAILED] Non-optional step failed, aborting plan`);
    }
  }

  // Final screenshot
  try {
    const finalFile = `final-${Date.now()}.png`;
    await page.screenshot({ path: path.join(screenshotDir, finalFile), fullPage: false });
  } catch {}

  // Cleanup listeners
  page.off('request', onRequest);
  page.off('response', onResponse);

  return results;
}

// ── Report Generation ──────────────────────────────────────────────────────

function generateReport(allResults, reportDir) {
  fs.mkdirSync(reportDir, { recursive: true });

  let totalPassed = 0;
  let totalFailed = 0;
  let rows = '';

  for (const result of allResults) {
    const passed = result.passed;
    const failed = result.failed;
    totalPassed += passed;
    totalFailed += failed;

    rows += `
        <tr class="${failed > 0 ? 'failed' : 'passed'}">
          <td>${result.scenario}</td>
          <td>${result.plan}</td>
          <td>${passed}</td>
          <td>${failed}</td>
          <td>${failed > 0 ? 'FAILED' : 'PASSED'}</td>
        </tr>`;

    for (const step of result.steps) {
      rows += `
          <tr class="step ${step.passed ? 'passed' : 'failed'}">
            <td colspan="2">&nbsp;&nbsp;Step ${step.stepIndex + 1}: ${step.action}${step.target ? ' → ' + step.target : ''}</td>
            <td colspan="2">${step.durationMs}ms</td>
            <td>${step.passed ? 'OK' : (step.skipped ? 'SKIPPED: ' + (step.reason || '') : (step.error || 'FAILED'))}</td>
          </tr>`;
    }
  }

  const total = totalPassed + totalFailed;
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>TestHub Execution Report</title>
<style>
body{font-family:system-ui,sans-serif;margin:2rem;background:#f5f5f5}
h1{color:#333}
.summary{display:flex;gap:1rem;margin:1rem 0}
.card{background:#fff;padding:1rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,.1)}
.card.passed{border-left:4px solid #28a745}
.card.failed{border-left:4px solid #dc3545}
table{width:100%;border-collapse:collapse;background:#fff;margin-top:1rem}
th,td{padding:.5rem 1rem;text-align:left;border-bottom:1px solid #eee}
th{background:#f8f9fa}
tr.passed{color:#28a745}
tr.failed{color:#dc3545}
tr.step{color:#666;font-size:.9em}
tr.step td:first-child{padding-left:2rem}
</style>
</head>
<body>
<h1>TestHub Execution Report</h1>
<div class="summary">
  <div class="card passed"><h3>${totalPassed}</h3><p>Passed</p></div>
  <div class="card failed"><h3>${totalFailed}</h3><p>Failed</p></div>
  <div class="card"><h3>${total}</h3><p>Total</p></div>
</div>
<table>
<thead><tr><th>Scenario</th><th>Plan</th><th>Passed</th><th>Failed</th><th>Status</th></tr></thead>
<tbody>${rows}</tbody>
</table>
</body>
</html>`;

  const reportPath = path.join(reportDir, 'index.html');
  fs.writeFileSync(reportPath, html);
  return reportPath;
}

// ── Main Entry Point ───────────────────────────────────────────────────────

async function main() {
  const opts = parseArgs();
  const logger = new SocketLogger();

  logger.push('=== ChatQA Executor Started ===');
  logger.push(`Spec file: ${opts.specFile}`);
  logger.push(`Variables: ${JSON.stringify(opts.variables)}`);

  let spec;
  try {
    spec = loadSpec(opts.specFile);
  } catch (err) {
    logger.push(`Failed to load spec: ${err.message}`);
    process.exit(1);
  }

  spec = resolveVariables(spec, opts.variables);

  let scenarios;
  if (spec.scenarios && Array.isArray(spec.scenarios)) {
    scenarios = spec.scenarios;
  } else if (spec.scenario_name && spec.steps) {
    scenarios = [{
      scenario_name: spec.scenario_name,
      plans: [{
        target_url: spec.target_url || '',
        description: spec.description || spec.scenario_name,
        steps: spec.steps,
      }],
    }];
  } else {
    logger.push('Invalid spec format: expected scenarios array or single case with scenario_name and steps');
    process.exit(1);
  }

  logger.push(`Loaded ${scenarios.length} scenarios`);

  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const allResults = [];

  try {
    for (const scenario of scenarios) {
      logger.push(`[scenario] ${scenario.scenario_name}`);

      const context = await browser.newContext();
      const page = await context.newPage();

      try {
        for (const plan of scenario.plans) {
          logger.push(`[plan] ${plan.description}`);

          const stepResults = await executePlan(page, plan, logger);
          const passed = stepResults.filter(r => r.passed).length;
          const failed = stepResults.filter(r => !r.passed).length;

          logger.push(`[plan done] ${plan.description} - passed: ${passed}, failed: ${failed}`);

          allResults.push({
            scenario: scenario.scenario_name,
            plan: plan.description,
            steps: stepResults,
            passed,
            failed,
          });
        }
      } finally {
        await context.close();
      }
    }
  } finally {
    await browser.close();
  }

  const reportDir = path.join(__dirname, '..', '..', 'reports');
  const reportPath = generateReport(allResults, reportDir);
  logger.push(`Report saved: ${reportPath}`);

  const totalPassed = allResults.reduce((sum, r) => sum + r.passed, 0);
  const totalFailed = allResults.reduce((sum, r) => sum + r.failed, 0);
  logger.push(`=== Execution Complete: ${totalPassed} passed, ${totalFailed} failed ===`);

  logger.close();

  if (totalFailed > 0) {
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
