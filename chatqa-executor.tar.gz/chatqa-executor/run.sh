#!/bin/bash

FILEPATH=""
PARAMS=""
REPORT_DIR="./reports"
AUTH_STATE=""

while getopts "f:p:d:a:" opt; do
  case $opt in
    f)
      FILEPATH="$OPTARG"
      ;;
    p)
      PARAMS="$OPTARG"
      ;;
    d)
      REPORT_DIR="$OPTARG"
      ;;
    a)
      AUTH_STATE="$OPTARG"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
    :)
      echo "Option -$OPTARG requires an argument" >&2
      exit 1
      ;;
  esac
done

export REPORT_DIR
export AUTH_STATE

if [ -z "$FILEPATH" ]; then
  echo "Error: -f filepath is required" >&2
  exit 1
fi

npm install --production 2>&1
TEST_PARAMS="$PARAMS" node src/index.js -f "$FILEPATH" -p "$PARAMS"
exit $?
